// 隐私政策页面逻辑
const dataCollection = require('../../utils/data-collection.js')

Page({
  data: {
    
  },

  onLoad(options) {
    console.log('隐私政策页面加载')
  },

  // 查看数据收集状态
  viewDataStatus() {
    const status = dataCollection.getDataCollectionStatus()
    
    let message = '数据收集状态：\n\n'
    
    // 用户同意状态
    const consent = status.consent
    message += '📋 授权状态：\n'
    message += `• 位置信息：${consent.location ? '已授权' : '未授权'}\n`
    message += `• 出生信息：${consent.birthInfo ? '已授权' : '未授权'}\n`
    message += `• 个人偏好：${consent.personalPrefs ? '已授权' : '未授权'}\n\n`
    
    // 数据统计
    message += '📊 数据统计：\n'
    message += `• 收集记录：${status.collectedData.length} 条\n`
    message += `• 匿名统计：${status.anonymousStats.length} 条\n\n`
    
    message += '💡 您可以随时撤销授权或清除数据'
    
    wx.showModal({
      title: '数据收集状态',
      content: message,
      showCancel: false,
      confirmText: '知道了'
    })
  },

  // 清除所有数据
  clearData() {
    wx.showModal({
      title: '确认清除',
      content: '这将清除所有本地存储的数据，包括：\n• 用户授权记录\n• 收集的个人数据\n• 匿名使用统计\n• 应用缓存数据\n\n此操作不可恢复，确定要继续吗？',
      confirmText: '确认清除',
      cancelText: '取消',
      confirmColor: '#ff4757',
      success: (res) => {
        if (res.confirm) {
          // 清除数据收集相关数据
          dataCollection.clearAllCollectedData()
          
          // 清除应用其他数据
          wx.clearStorageSync()
          
          wx.showToast({
            title: '数据已全部清除',
            icon: 'success',
            duration: 2000
          })
          
          // 延迟返回，让用户看到提示
          setTimeout(() => {
            wx.navigateBack()
          }, 2000)
        }
      }
    })
  },

  // 返回上一页
  goBack() {
    wx.navigateBack()
  },

  // 分享功能
  onShareAppMessage() {
    return {
      title: 'MOONA星座小程序 - 保护您的隐私',
      path: '/pages/index/index'
    }
  }
})