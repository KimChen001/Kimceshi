// pages/matching/matching.js
Page({
  data: {
    selectedMatchType: null,
    zodiac1: '',
    zodiac2: '',
    matching: false,
    matchResult: null,
    matchHistory: [],
    matchTypes: [
      {
        id: 1,
        name: '恋人配对',
        description: '分析你们的爱情兼容性',
        icon: '💕',
        label1: '你的星座',
        label2: 'TA的星座'
      },
      {
        id: 2,
        name: '朋友配对',
        description: '看看你们能成为好朋友吗',
        icon: '👫',
        label1: '你的星座',
        label2: '朋友的星座'
      },
      {
        id: 3,
        name: '同事配对',
        description: '工作合作的默契程度',
        icon: '🤝',
        label1: '你的星座',
        label2: '同事的星座'
      },
      {
        id: 4,
        name: '家人配对',
        description: '家庭关系的和谐指数',
        icon: '👨‍👩‍👧‍👦',
        label1: '你的星座',
        label2: '家人的星座'
      }
    ],
    allZodiacs: [
      '白羊座', '金牛座', '双子座', '巨蟹座', 
      '狮子座', '处女座', '天秤座', '天蝎座', 
      '射手座', '摩羯座', '水瓶座', '双鱼座'
    ]
  },

  onLoad() {
    this.loadMatchHistory()
  },

  // 加载配对历史
  loadMatchHistory() {
    const history = wx.getStorageSync('matchHistory') || []
    this.setData({ matchHistory: history })
  },

  // 选择配对类型
  selectMatchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({ 
      selectedMatchType: type,
      zodiac1: '',
      zodiac2: '',
      matchResult: null
    })
  },

  // 选择第一个星座
  selectZodiac1(e) {
    const zodiac = e.currentTarget.dataset.zodiac
    this.setData({ zodiac1: zodiac })
  },

  // 选择第二个星座
  selectZodiac2(e) {
    const zodiac = e.currentTarget.dataset.zodiac
    this.setData({ zodiac2: zodiac })
  },

  // 开始配对分析
  startMatching() {
    const { zodiac1, zodiac2, selectedMatchType } = this.data
    
    if (!zodiac1 || !zodiac2) {
      wx.showToast({
        title: '请选择两个星座',
        icon: 'none'
      })
      return
    }

    this.setData({ matching: true })

    // 模拟分析延迟
    setTimeout(() => {
      const result = this.calculateMatch(zodiac1, zodiac2, selectedMatchType)
      
      this.setData({
        matchResult: result,
        matching: false
      })

      // 保存到历史记录
      this.saveToHistory(result)
    }, 2000)
  },

  // 计算配对结果
  calculateMatch(zodiac1, zodiac2, matchType) {
    // 星座元素映射
    const elements = {
      '白羊座': '火', '狮子座': '火', '射手座': '火',
      '金牛座': '土', '处女座': '土', '摩羯座': '土',
      '双子座': '风', '天秤座': '风', '水瓶座': '风',
      '巨蟹座': '水', '天蝎座': '水', '双鱼座': '水'
    }

    // 星座模式映射
    const modalities = {
      '白羊座': '基本', '巨蟹座': '基本', '天秤座': '基本', '摩羯座': '基本',
      '金牛座': '固定', '狮子座': '固定', '天蝎座': '固定', '水瓶座': '固定',
      '双子座': '变动', '处女座': '变动', '射手座': '变动', '双鱼座': '变动'
    }

    const element1 = elements[zodiac1]
    const element2 = elements[zodiac2]
    const modality1 = modalities[zodiac1]
    const modality2 = modalities[zodiac2]

    // 基础兼容性计算
    let baseScore = 50
    
    // 元素兼容性
    if (element1 === element2) {
      baseScore += 20 // 同元素
    } else if (
      (element1 === '火' && element2 === '风') ||
      (element1 === '风' && element2 === '火') ||
      (element1 === '土' && element2 === '水') ||
      (element1 === '水' && element2 === '土')
    ) {
      baseScore += 15 // 互补元素
    } else if (
      (element1 === '火' && element2 === '土') ||
      (element1 === '土' && element2 === '火') ||
      (element1 === '风' && element2 === '水') ||
      (element1 === '水' && element2 === '风')
    ) {
      baseScore -= 10 // 冲突元素
    }

    // 模式兼容性
    if (modality1 === modality2) {
      baseScore += 10
    }

    // 特殊配对加成
    const specialPairs = {
      '白羊座-狮子座': 85, '白羊座-射手座': 82, '白羊座-双子座': 78,
      '金牛座-处女座': 88, '金牛座-摩羯座': 85, '金牛座-巨蟹座': 80,
      '双子座-天秤座': 86, '双子座-水瓶座': 83, '双子座-白羊座': 78,
      '巨蟹座-天蝎座': 90, '巨蟹座-双鱼座': 87, '巨蟹座-金牛座': 80,
      '狮子座-射手座': 88, '狮子座-白羊座': 85, '狮子座-双子座': 75,
      '处女座-摩羯座': 89, '处女座-金牛座': 88, '处女座-天蝎座': 76,
      '天秤座-水瓶座': 87, '天秤座-双子座': 86, '天秤座-狮子座': 79,
      '天蝎座-双鱼座': 91, '天蝎座-巨蟹座': 90, '天蝎座-处女座': 76,
      '射手座-白羊座': 82, '射手座-狮子座': 88, '射手座-水瓶座': 77,
      '摩羯座-处女座': 89, '摩羯座-金牛座': 85, '摩羯座-天蝎座': 78,
      '水瓶座-双子座': 83, '水瓶座-天秤座': 87, '水瓶座-射手座': 77,
      '双鱼座-巨蟹座': 87, '双鱼座-天蝎座': 91, '双鱼座-摩羯座': 74
    }

    const pairKey1 = `${zodiac1}-${zodiac2}`
    const pairKey2 = `${zodiac2}-${zodiac1}`
    
    if (specialPairs[pairKey1]) {
      baseScore = specialPairs[pairKey1]
    } else if (specialPairs[pairKey2]) {
      baseScore = specialPairs[pairKey2]
    }

    // 根据配对类型调整
    switch (matchType.id) {
      case 1: // 恋人配对
        break // 使用基础分数
      case 2: // 朋友配对
        baseScore += 5 // 友情更容易
        break
      case 3: // 同事配对
        if (modality1 !== modality2) baseScore += 8 // 不同模式在工作中互补
        break
      case 4: // 家人配对
        baseScore += 10 // 家人关系更包容
        break
    }

    // 确保分数在合理范围内
    baseScore = Math.max(30, Math.min(95, baseScore))

    // 生成详细分析
    const result = {
      zodiac1,
      zodiac2,
      type: matchType.name,
      score: baseScore,
      overall: this.generateOverallAnalysis(zodiac1, zodiac2, baseScore, matchType),
      strengths: this.generateStrengths(element1, element2, modality1, modality2, matchType),
      challenges: this.generateChallenges(element1, element2, modality1, modality2, matchType),
      suggestions: this.generateSuggestions(element1, element2, matchType),
      dimensions: this.generateDimensions(element1, element2, modality1, modality2, matchType),
      time: new Date()
    }

    return result
  },

  // 生成整体分析
  generateOverallAnalysis(zodiac1, zodiac2, score, matchType) {
    const level = this.getScoreText(score)
    const typeText = matchType.name.replace('配对', '')
    
    if (score >= 85) {
      return `${zodiac1}和${zodiac2}在${typeText}方面有着极高的默契！你们的性格互补，能够很好地理解和支持彼此。这是一段值得珍惜的关系。`
    } else if (score >= 70) {
      return `${zodiac1}和${zodiac2}的${typeText}关系相当不错。虽然偶尔会有小摩擦，但总体来说你们能够和谐相处，共同成长。`
    } else if (score >= 55) {
      return `${zodiac1}和${zodiac2}的${typeText}关系需要更多的理解和包容。通过沟通和努力，你们可以建立更好的关系。`
    } else {
      return `${zodiac1}和${zodiac2}在${typeText}方面可能会遇到一些挑战。但记住，星座只是参考，真正的关系需要双方的努力和理解。`
    }
  },

  // 生成优势分析
  generateStrengths(element1, element2, modality1, modality2, matchType) {
    const strengths = []
    
    if (element1 === element2) {
      strengths.push('你们有着相似的价值观和生活节奏')
      strengths.push('能够很好地理解彼此的想法和感受')
    }
    
    if (modality1 === modality2) {
      strengths.push('处事方式相近，容易达成共识')
    }
    
    // 根据元素组合添加特定优势
    const elementPair = [element1, element2].sort().join('-')
    const elementStrengths = {
      '火-火': ['充满激情和活力', '都喜欢冒险和挑战'],
      '土-土': ['务实稳重，目标一致', '都重视安全感和稳定'],
      '风-风': ['沟通顺畅，思维活跃', '都喜欢自由和变化'],
      '水-水': ['情感深厚，直觉敏锐', '都很重视情感交流'],
      '火-风': ['激情与理性的完美结合', '能够互相激发创造力'],
      '土-水': ['稳定与感性的和谐统一', '能够给彼此安全感']
    }
    
    if (elementStrengths[elementPair]) {
      strengths.push(...elementStrengths[elementPair])
    }
    
    return strengths.slice(0, 3) // 最多3个优势
  },

  // 生成挑战分析
  generateChallenges(element1, element2, modality1, modality2, matchType) {
    const challenges = []
    
    if (element1 === '火' && element2 === '水') {
      challenges.push('火象的冲动可能与水象的敏感产生冲突')
    } else if (element1 === '土' && element2 === '风') {
      challenges.push('土象的保守可能与风象的变化产生分歧')
    }
    
    if (modality1 === '基本' && modality2 === '固定') {
      challenges.push('主导欲可能与固执产生摩擦')
    }
    
    // 通用挑战
    challenges.push('需要更多的耐心和理解')
    challenges.push('在重要决定上可能需要更多沟通')
    
    return challenges.slice(0, 2) // 最多2个挑战
  },

  // 生成建议
  generateSuggestions(element1, element2, matchType) {
    const suggestions = []
    
    if (matchType.id === 1) { // 恋人
      suggestions.push('多花时间了解彼此的内心世界')
      suggestions.push('保持浪漫，创造美好的回忆')
      suggestions.push('遇到分歧时要冷静沟通')
    } else if (matchType.id === 2) { // 朋友
      suggestions.push('多参加共同感兴趣的活动')
      suggestions.push('给彼此足够的个人空间')
      suggestions.push('在困难时互相支持')
    } else if (matchType.id === 3) { // 同事
      suggestions.push('发挥各自的专业优势')
      suggestions.push('建立清晰的工作分工')
      suggestions.push('保持专业的沟通方式')
    } else { // 家人
      suggestions.push('尊重彼此的生活方式')
      suggestions.push('多创造家庭聚会的机会')
      suggestions.push('在家庭决定中多听取意见')
    }
    
    return suggestions
  },

  // 生成各维度评分
  generateDimensions(element1, element2, modality1, modality2, matchType) {
    const dimensions = []
    
    if (matchType.id === 1) { // 恋人配对
      dimensions.push(
        { name: '情感契合', score: this.calculateDimensionScore(element1, element2, 'emotion') },
        { name: '沟通理解', score: this.calculateDimensionScore(element1, element2, 'communication') },
        { name: '生活节奏', score: this.calculateDimensionScore(modality1, modality2, 'lifestyle') },
        { name: '未来规划', score: this.calculateDimensionScore(element1, element2, 'future') }
      )
    } else if (matchType.id === 2) { // 朋友配对
      dimensions.push(
        { name: '兴趣相投', score: this.calculateDimensionScore(element1, element2, 'interest') },
        { name: '价值观', score: this.calculateDimensionScore(element1, element2, 'values') },
        { name: '信任度', score: this.calculateDimensionScore(element1, element2, 'trust') },
        { name: '互助性', score: this.calculateDimensionScore(modality1, modality2, 'support') }
      )
    } else if (matchType.id === 3) { // 同事配对
      dimensions.push(
        { name: '工作效率', score: this.calculateDimensionScore(modality1, modality2, 'efficiency') },
        { name: '团队协作', score: this.calculateDimensionScore(element1, element2, 'teamwork') },
        { name: '创新能力', score: this.calculateDimensionScore(element1, element2, 'innovation') },
        { name: '目标一致', score: this.calculateDimensionScore(element1, element2, 'goals') }
      )
    } else { // 家人配对
      dimensions.push(
        { name: '理解包容', score: this.calculateDimensionScore(element1, element2, 'understanding') },
        { name: '生活习惯', score: this.calculateDimensionScore(modality1, modality2, 'habits') },
        { name: '情感支持', score: this.calculateDimensionScore(element1, element2, 'emotional_support') },
        { name: '和谐度', score: this.calculateDimensionScore(element1, element2, 'harmony') }
      )
    }
    
    return dimensions
  },

  // 计算单个维度分数
  calculateDimensionScore(attr1, attr2, type) {
    let score = 7 // 基础分数
    
    if (attr1 === attr2) {
      score += 2 // 相同属性加分
    }
    
    // 根据维度类型调整
    const adjustments = {
      'emotion': attr1 === '水' || attr2 === '水' ? 1 : 0,
      'communication': attr1 === '风' || attr2 === '风' ? 1 : 0,
      'efficiency': attr1 === '土' || attr2 === '土' ? 1 : 0,
      'innovation': attr1 === '火' || attr2 === '火' ? 1 : 0
    }
    
    score += adjustments[type] || 0
    score += Math.random() * 2 - 1 // 随机调整
    
    return Math.max(5, Math.min(10, Math.round(score)))
  },

  // 保存到历史记录
  saveToHistory(result) {
    let history = wx.getStorageSync('matchHistory') || []
    
    // 添加ID和简化数据
    const historyItem = {
      id: Date.now(),
      zodiac1: result.zodiac1,
      zodiac2: result.zodiac2,
      score: result.score,
      type: result.type,
      time: result.time
    }
    
    history.unshift(historyItem)
    
    // 最多保存20条记录
    if (history.length > 20) {
      history = history.slice(0, 20)
    }
    
    wx.setStorageSync('matchHistory', history)
    this.setData({ matchHistory: history })
  },

  // 查看历史结果
  viewHistoryResult(e) {
    const result = e.currentTarget.dataset.result
    wx.showToast({
      title: '历史详情功能开发中',
      icon: 'none'
    })
  },

  // 重新配对
  resetMatching() {
    this.setData({
      selectedMatchType: null,
      zodiac1: '',
      zodiac2: '',
      matchResult: null
    })
  },

  // 分享结果
  shareResult() {
    wx.showToast({
      title: '分享功能开发中',
      icon: 'none'
    })
  },

  // 获取星座符号
  getZodiacSymbol(sign) {
    const symbols = {
      '白羊座': '♈', '金牛座': '♉', '双子座': '♊', '巨蟹座': '♋',
      '狮子座': '♌', '处女座': '♍', '天秤座': '♎', '天蝎座': '♏',
      '射手座': '♐', '摩羯座': '♑', '水瓶座': '♒', '双鱼座': '♓'
    }
    return symbols[sign] || '⭐'
  },

  // 获取分数等级
  getScoreLevel(score) {
    if (score >= 85) return 'excellent'
    if (score >= 70) return 'good'
    if (score >= 55) return 'average'
    return 'poor'
  },

  // 获取分数文字
  getScoreText(score) {
    if (score >= 85) return '天作之合'
    if (score >= 70) return '相当匹配'
    if (score >= 55) return '需要努力'
    return '充满挑战'
  },

  // 格式化时间
  formatTime(date) {
    const now = new Date()
    const time = new Date(date)
    const diff = now - time
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    if (days === 0) return '今天'
    if (days === 1) return '昨天'
    if (days < 7) return `${days}天前`
    
    return time.toLocaleDateString()
  }
})