// app.js
App({
  onLaunch() {
    console.log('星座运势小程序启动')
  },

  globalData: {
    userInfo: null,
    
    // API提供商选择：'coze', 'openai', 'baidu', 'ali'
    apiProvider: 'coze',
    
    // Coze API配置
    cozeApiUrl: 'https://api.coze.cn/open_api/v2/chat',
    cozeApiKey: 'pat_oVzXN1jznil5aJg9EwgRiIf9VQW0fuFJEzJ221wWrr3ZUYbHEWP9Le6IvrTwtfRx',
    zodiacWorkflowId: '7534037886100258855',
    fortuneWorkflowId: '7534374490055950345',
    
    // OpenAI API配置（备用）
    openaiApiUrl: 'https://api.openai.com/v1/chat/completions',
    openaiApiKey: '', // 您的OpenAI API Key
    
    // 百度文心一言API配置（备用）
    baiduApiUrl: 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions',
    baiduApiKey: '', // 您的百度API Key
    
    // API请求配置
    apiTimeout: 30000,
    retryTimes: 2
  }
})