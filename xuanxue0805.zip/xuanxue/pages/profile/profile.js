// pages/profile/profile.js
const app = getApp()

Page({
  data: {
    userInfo: null,
    currentTab: 'fortune',
    collections: {
      fortune: [],
      tarot: [],
      posts: []
    },
    userStats: {
      fortuneCount: 0,
      tarotCount: 0,
      matchCount: 0,
      postCount: 0,
      daysUsed: 1
    },
    settings: {
      dailyNotification: false
    },
    personalityTraits: []
  },

  onLoad() {
    this.loadUserInfo()
    this.loadCollections()
    this.loadUserStats()
    this.loadSettings()
    this.generatePersonalityTraits()
  },

  onShow() {
    // 每次显示时更新数据
    this.loadUserInfo()
    this.loadUserStats()
  },

  onReady() {
    // 页面渲染完成后绘制雷达图
    setTimeout(() => {
      this.drawRadarChart()
    }, 500)
  },

  // 加载用户信息
  loadUserInfo() {
    const userInfo = app.globalData.userInfo
    if (userInfo) {
      this.setData({ userInfo })
    } else {
      // 如果没有用户信息，显示提示
      wx.showModal({
        title: '提示',
        content: '请先完成星座分析以查看个人档案',
        confirmText: '去分析',
        success: (res) => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/index/index'
            })
          }
        }
      })
    }
  },

  // 加载收藏数据
  loadCollections() {
    const collections = {
      fortune: wx.getStorageSync('fortuneCollections') || [],
      tarot: wx.getStorageSync('tarotCollections') || [],
      posts: wx.getStorageSync('postCollections') || []
    }
    this.setData({ collections })
  },

  // 加载用户统计
  loadUserStats() {
    const stats = wx.getStorageSync('userStats') || {
      fortuneCount: Math.floor(Math.random() * 20) + 1,
      tarotCount: Math.floor(Math.random() * 15) + 1,
      matchCount: Math.floor(Math.random() * 10) + 1,
      postCount: Math.floor(Math.random() * 8) + 1,
      daysUsed: Math.floor(Math.random() * 30) + 1
    }
    this.setData({ userStats: stats })
    wx.setStorageSync('userStats', stats)
  },

  // 加载设置
  loadSettings() {
    const settings = wx.getStorageSync('userSettings') || {
      dailyNotification: false
    }
    this.setData({ settings })
  },

  // 生成性格特质数据
  generatePersonalityTraits() {
    const { userInfo } = this.data
    if (!userInfo || !userInfo.zodiacInfo) return

    const sign = userInfo.zodiacInfo.sign
    const element = this.getZodiacElement(sign)
    
    // 根据星座生成性格特质分数
    const baseTraits = {
      '白羊座': { 冒险性: 9, 领导力: 8, 耐心: 4, 创造力: 7, 社交性: 7, 稳定性: 5 },
      '金牛座': { 冒险性: 3, 领导力: 6, 耐心: 9, 创造力: 6, 社交性: 5, 稳定性: 9 },
      '双子座': { 冒险性: 7, 领导力: 6, 耐心: 4, 创造力: 8, 社交性: 9, 稳定性: 4 },
      '巨蟹座': { 冒险性: 4, 领导力: 5, 耐心: 8, 创造力: 7, 社交性: 6, 稳定性: 7 },
      '狮子座': { 冒险性: 8, 领导力: 9, 耐心: 5, 创造力: 8, 社交性: 9, 稳定性: 6 },
      '处女座': { 冒险性: 3, 领导力: 7, 耐心: 8, 创造力: 6, 社交性: 5, 稳定性: 8 },
      '天秤座': { 冒险性: 5, 领导力: 6, 耐心: 6, 创造力: 7, 社交性: 9, 稳定性: 6 },
      '天蝎座': { 冒险性: 6, 领导力: 8, 耐心: 7, 创造力: 8, 社交性: 5, 稳定性: 7 },
      '射手座': { 冒险性: 9, 领导力: 7, 耐心: 4, 创造力: 8, 社交性: 8, 稳定性: 4 },
      '摩羯座': { 冒险性: 4, 领导力: 8, 耐心: 8, 创造力: 5, 社交性: 5, 稳定性: 9 },
      '水瓶座': { 冒险性: 7, 领导力: 6, 耐心: 5, 创造力: 9, 社交性: 7, 稳定性: 5 },
      '双鱼座': { 冒险性: 5, 领导力: 4, 耐心: 7, 创造力: 9, 社交性: 6, 稳定性: 6 }
    }

    const traits = baseTraits[sign] || baseTraits['白羊座']
    const colors = ['#ff6b9d', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dda0dd']
    
    const personalityTraits = Object.keys(traits).map((key, index) => ({
      name: key,
      score: traits[key],
      color: colors[index % colors.length]
    }))

    this.setData({ personalityTraits })
  },

  // 绘制雷达图
  drawRadarChart() {
    const { personalityTraits } = this.data
    if (personalityTraits.length === 0) return

    const ctx = wx.createCanvasContext('radarCanvas', this)
    const centerX = 150
    const centerY = 150
    const radius = 100
    const sides = personalityTraits.length

    // 清除画布
    ctx.clearRect(0, 0, 300, 300)

    // 绘制背景网格
    ctx.setStrokeStyle('#333')
    ctx.setLineWidth(1)
    
    for (let i = 1; i <= 5; i++) {
      const r = (radius / 5) * i
      ctx.beginPath()
      for (let j = 0; j < sides; j++) {
        const angle = (Math.PI * 2 * j) / sides - Math.PI / 2
        const x = centerX + Math.cos(angle) * r
        const y = centerY + Math.sin(angle) * r
        if (j === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }
      ctx.closePath()
      ctx.stroke()
    }

    // 绘制轴线
    for (let i = 0; i < sides; i++) {
      const angle = (Math.PI * 2 * i) / sides - Math.PI / 2
      const x = centerX + Math.cos(angle) * radius
      const y = centerY + Math.sin(angle) * radius
      
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.lineTo(x, y)
      ctx.stroke()

      // 绘制标签
      ctx.setFillStyle('#fff')
      ctx.setFontSize(12)
      ctx.setTextAlign('center')
      const labelX = centerX + Math.cos(angle) * (radius + 20)
      const labelY = centerY + Math.sin(angle) * (radius + 20)
      ctx.fillText(personalityTraits[i].name, labelX, labelY)
    }

    // 绘制数据区域
    ctx.setFillStyle('rgba(255, 107, 157, 0.3)')
    ctx.setStrokeStyle('#ff6b9d')
    ctx.setLineWidth(2)
    
    ctx.beginPath()
    for (let i = 0; i < sides; i++) {
      const angle = (Math.PI * 2 * i) / sides - Math.PI / 2
      const score = personalityTraits[i].score
      const r = (radius / 10) * score
      const x = centerX + Math.cos(angle) * r
      const y = centerY + Math.sin(angle) * r
      
      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }

      // 绘制数据点
      ctx.beginPath()
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.setFillStyle('#ff6b9d')
      ctx.fill()
    }
    ctx.closePath()
    ctx.fill()
    ctx.stroke()

    ctx.draw()
  },

  // 雷达图触摸事件
  onRadarTouch(e) {
    // 可以添加交互功能
    console.log('雷达图被触摸', e)
  },

  // 切换收藏标签
  switchTab(e) {
    const tab = e.currentTarget.dataset.tab
    this.setData({ currentTab: tab })
  },

  // 通知设置改变
  onNotificationChange(e) {
    const enabled = e.detail.value
    this.setData({
      'settings.dailyNotification': enabled
    })
    
    const settings = { ...this.data.settings, dailyNotification: enabled }
    wx.setStorageSync('userSettings', settings)
    
    wx.showToast({
      title: enabled ? '已开启推送' : '已关闭推送',
      icon: 'success'
    })
  },

  // 清除缓存
  clearCache() {
    wx.showModal({
      title: '确认清除',
      content: '这将清除所有本地数据，包括收藏和设置',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync()
          wx.showToast({
            title: '清除成功',
            icon: 'success'
          })
          
          // 重新加载数据
          setTimeout(() => {
            this.loadCollections()
            this.loadUserStats()
            this.loadSettings()
          }, 1000)
        }
      }
    })
  },

  // 分享小程序
  shareApp() {
    wx.showToast({
      title: '长按小程序图标分享',
      icon: 'none'
    })
  },

  // 查看隐私政策
  viewPrivacyPolicy() {
    wx.navigateTo({
      url: '/pages/privacy/privacy'
    })
  },

  // 联系我们
  contactUs() {
    wx.showModal({
      title: '联系我们',
      content: '如有问题或建议，请通过以下方式联系我们：\n\n📧 邮箱：kimxcx@163.com\n🕐 回复时间：24小时内\n\n我们重视每一位用户的反馈！',
      confirmText: '知道了'
    })
  },

  // 获取星座符号
  getZodiacSymbol(sign) {
    const symbols = {
      '白羊座': '♈', '金牛座': '♉', '双子座': '♊', '巨蟹座': '♋',
      '狮子座': '♌', '处女座': '♍', '天秤座': '♎', '天蝎座': '♏',
      '射手座': '♐', '摩羯座': '♑', '水瓶座': '♒', '双鱼座': '♓'
    }
    return symbols[sign] || '⭐'
  },

  // 获取星座描述
  getZodiacDescription(sign) {
    const descriptions = {
      '白羊座': '热情活力，勇敢直率，天生的领导者',
      '金牛座': '稳重踏实，享受生活，对美有独特品味',
      '双子座': '聪明机智，善于沟通，充满好奇心',
      '巨蟹座': '温柔体贴，重视家庭，情感丰富',
      '狮子座': '自信大方，慷慨热情，天生的表演者',
      '处女座': '细致认真，追求完美，善于分析',
      '天秤座': '优雅和谐，追求平衡，社交能力强',
      '天蝎座': '神秘深邃，意志坚强，洞察力敏锐',
      '射手座': '自由奔放，乐观向上，热爱冒险',
      '摩羯座': '务实稳重，目标明确，责任心强',
      '水瓶座': '独立创新，思想前卫，人道主义',
      '双鱼座': '浪漫梦幻，直觉敏锐，富有同情心'
    }
    return descriptions[sign] || '独特而神秘的星座'
  },

  // 获取星座元素
  getZodiacElement(sign) {
    const elements = {
      '白羊座': '火', '狮子座': '火', '射手座': '火',
      '金牛座': '土', '处女座': '土', '摩羯座': '土',
      '双子座': '风', '天秤座': '风', '水瓶座': '风',
      '巨蟹座': '水', '天蝎座': '水', '双鱼座': '水'
    }
    return elements[sign] || '火'
  },

  // 获取幸运元素
  getZodiacLucky(sign) {
    const lucky = {
      '白羊座': { number: [6, 7], color: ['红色', '橙色'], stone: '红宝石' },
      '金牛座': { number: [1, 9], color: ['绿色', '粉色'], stone: '翡翠' },
      '双子座': { number: [3, 5], color: ['黄色', '银色'], stone: '玛瑙' },
      '巨蟹座': { number: [2, 8], color: ['白色', '银色'], stone: '珍珠' },
      '狮子座': { number: [1, 3], color: ['金色', '橙色'], stone: '黄水晶' },
      '处女座': { number: [3, 8], color: ['灰色', '米色'], stone: '蓝宝石' },
      '天秤座': { number: [6, 9], color: ['蓝色', '粉色'], stone: '欧泊' },
      '天蝎座': { number: [4, 13], color: ['深红', '黑色'], stone: '黑曜石' },
      '射手座': { number: [9, 21], color: ['紫色', '深蓝'], stone: '绿松石' },
      '摩羯座': { number: [3, 22], color: ['黑色', '深绿'], stone: '石榴石' },
      '水瓶座': { number: [4, 11], color: ['蓝色', '银色'], stone: '紫水晶' },
      '双鱼座': { number: [11, 29], color: ['海绿', '紫色'], stone: '海蓝宝' }
    }
    return lucky[sign] || { number: [7, 14], color: ['金色', '银色'], stone: '水晶' }
  },

  // 获取幸运方位
  getLuckyDirection(sign) {
    const directions = {
      '白羊座': '东方', '金牛座': '东南', '双子座': '西方', '巨蟹座': '北方',
      '狮子座': '南方', '处女座': '西南', '天秤座': '西方', '天蝎座': '北方',
      '射手座': '南方', '摩羯座': '北方', '水瓶座': '南方', '双鱼座': '东方'
    }
    return directions[sign] || '东方'
  },

  // 格式化时间
  formatTime(date) {
    const now = new Date()
    const time = new Date(date)
    const diff = now - time
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    if (days === 0) return '今天'
    if (days === 1) return '昨天'
    if (days < 7) return `${days}天前`
    
    return time.toLocaleDateString()
  }
})