// pages/tarot/tarot.js
Page({
  data: {
    selectedSpread: null,
    userQuestion: '',
    deckCards: [],
    drawnCards: [],
    drawComplete: false,
    drawingCard: false,
    overallInterpretation: '',
    showCardDetail: false,
    selectedCard: null,
    tarotSpreads: [
      {
        id: 1,
        name: '每日一抽',
        description: '了解今日运势和需要注意的事项',
        icon: '🌅',
        cardCount: 1
      },
      {
        id: 2,
        name: '爱情三角',
        description: '探索你的感情状况和发展方向',
        icon: '💕',
        cardCount: 3
      },
      {
        id: 3,
        name: '事业指引',
        description: '获得工作和事业方面的建议',
        icon: '💼',
        cardCount: 3
      },
      {
        id: 4,
        name: '人生十字',
        description: '全面了解当前生活状态和未来走向',
        icon: '✨',
        cardCount: 4
      }
    ],
    tarotCards: [
      {
        id: 1,
        name: '愚者',
        symbol: '🃏',
        uprightMeaning: '新的开始、纯真、自发性、自由精神',
        reversedMeaning: '鲁莽、冒险、愚蠢的选择',
        keywords: ['新开始', '冒险', '纯真', '自由']
      },
      {
        id: 2,
        name: '魔术师',
        symbol: '🎩',
        uprightMeaning: '意志力、渴望、创造、显化',
        reversedMeaning: '操控、缺乏计划、未发挥的才能',
        keywords: ['创造力', '意志力', '技能', '专注']
      },
      {
        id: 3,
        name: '女祭司',
        symbol: '🌙',
        uprightMeaning: '直觉、潜意识、神秘、内在智慧',
        reversedMeaning: '缺乏内在声音、压抑直觉、秘密',
        keywords: ['直觉', '智慧', '潜意识', '神秘']
      },
      {
        id: 4,
        name: '皇后',
        symbol: '👸',
        uprightMeaning: '女性力量、美丽、自然、丰饶',
        reversedMeaning: '创造力被阻、依赖他人、空虚',
        keywords: ['丰饶', '母性', '创造', '自然']
      },
      {
        id: 5,
        name: '皇帝',
        symbol: '👑',
        uprightMeaning: '权威、结构、控制、父权',
        reversedMeaning: '专制、缺乏纪律、不负责任',
        keywords: ['权威', '稳定', '控制', '领导']
      },
      {
        id: 6,
        name: '教皇',
        symbol: '⛪',
        uprightMeaning: '精神指导、传统、符合、宗教',
        reversedMeaning: '个人信仰、自由、挑战现状',
        keywords: ['传统', '指导', '信仰', '学习']
      },
      {
        id: 7,
        name: '恋人',
        symbol: '💑',
        uprightMeaning: '爱情、和谐、关系、选择',
        reversedMeaning: '失去平衡、单恋、不和谐',
        keywords: ['爱情', '选择', '关系', '和谐']
      },
      {
        id: 8,
        name: '战车',
        symbol: '🏆',
        uprightMeaning: '控制、意志力、成功、决心',
        reversedMeaning: '缺乏控制、缺乏方向、侵略',
        keywords: ['胜利', '决心', '控制', '成功']
      },
      {
        id: 9,
        name: '力量',
        symbol: '🦁',
        uprightMeaning: '力量、勇气、耐心、控制',
        reversedMeaning: '自我怀疑、缺乏信心、原始情绪',
        keywords: ['勇气', '耐心', '控制', '内在力量']
      },
      {
        id: 10,
        name: '隐者',
        symbol: '🕯️',
        uprightMeaning: '内省、寻求内在指导、独处',
        reversedMeaning: '孤立、迷失、拒绝帮助',
        keywords: ['内省', '指导', '独处', '智慧']
      },
      {
        id: 11,
        name: '命运之轮',
        symbol: '☸️',
        uprightMeaning: '好运、业力、生命周期、命运',
        reversedMeaning: '坏运气、缺乏控制、破坏性循环',
        keywords: ['命运', '变化', '周期', '机遇']
      },
      {
        id: 12,
        name: '正义',
        symbol: '⚖️',
        uprightMeaning: '正义、公平、真相、因果',
        reversedMeaning: '不公正、缺乏问责、不诚实',
        keywords: ['正义', '平衡', '真相', '公平']
      },
      {
        id: 13,
        name: '倒吊人',
        symbol: '🙃',
        uprightMeaning: '暂停、放手、牺牲、新视角',
        reversedMeaning: '拖延、抵抗、停滞',
        keywords: ['牺牲', '等待', '新视角', '暂停']
      },
      {
        id: 14,
        name: '死神',
        symbol: '💀',
        uprightMeaning: '结束、转变、过渡、重生',
        reversedMeaning: '抵抗变化、停滞、腐朽',
        keywords: ['转变', '结束', '重生', '变化']
      },
      {
        id: 15,
        name: '节制',
        symbol: '🏺',
        uprightMeaning: '平衡、节制、耐心、目标',
        reversedMeaning: '不平衡、过度、缺乏长期视野',
        keywords: ['平衡', '和谐', '耐心', '节制']
      },
      {
        id: 16,
        name: '恶魔',
        symbol: '😈',
        uprightMeaning: '束缚、成瘾、性、物质主义',
        reversedMeaning: '释放限制、恢复控制、脱离束缚',
        keywords: ['诱惑', '束缚', '物质', '欲望']
      },
      {
        id: 17,
        name: '塔',
        symbol: '🗼',
        uprightMeaning: '突然改变、动荡、混乱、启示',
        reversedMeaning: '个人转变、恐惧变化、灾难避免',
        keywords: ['突变', '破坏', '启示', '解放']
      },
      {
        id: 18,
        name: '星星',
        symbol: '⭐',
        uprightMeaning: '希望、信仰、目标、更新',
        reversedMeaning: '缺乏信仰、绝望、自我信任',
        keywords: ['希望', '灵感', '指导', '平静']
      },
      {
        id: 19,
        name: '月亮',
        symbol: '🌙',
        uprightMeaning: '幻象、恐惧、焦虑、潜意识',
        reversedMeaning: '释放恐惧、压抑情绪、内在混乱',
        keywords: ['幻象', '直觉', '恐惧', '潜意识']
      },
      {
        id: 20,
        name: '太阳',
        symbol: '☀️',
        uprightMeaning: '快乐、成功、庆祝、积极',
        reversedMeaning: '内在快乐、过度乐观、自负',
        keywords: ['快乐', '成功', '活力', '积极']
      },
      {
        id: 21,
        name: '审判',
        symbol: '📯',
        uprightMeaning: '审判、重生、内在呼唤、宽恕',
        reversedMeaning: '自我怀疑、严厉的自我批评、缺乏自我意识',
        keywords: ['重生', '觉醒', '审判', '宽恕']
      },
      {
        id: 22,
        name: '世界',
        symbol: '🌍',
        uprightMeaning: '完成、成就、旅行、满足',
        reversedMeaning: '寻求个人结束、缺乏成就、延迟',
        keywords: ['完成', '成就', '满足', '成功']
      }
    ]
  },

  onLoad() {
    this.initializeDeck()
  },

  // 初始化牌组
  initializeDeck() {
    const deck = []
    for (let i = 0; i < 22; i++) {
      deck.push({ index: i })
    }
    this.setData({ deckCards: deck })
  },

  // 选择占卜类型
  selectSpread(e) {
    const spread = e.currentTarget.dataset.spread
    this.setData({ 
      selectedSpread: spread,
      drawnCards: [],
      drawComplete: false
    })
  },

  // 输入问题
  onQuestionInput(e) {
    this.setData({
      userQuestion: e.detail.value
    })
  },

  // 抽牌
  drawCard(e) {
    const { drawnCards, selectedSpread, tarotCards, drawingCard } = this.data
    
    if (drawingCard || drawnCards.length >= selectedSpread.cardCount) {
      return
    }

    this.setData({ drawingCard: true })

    // 随机选择一张牌
    const availableCards = tarotCards.filter(card => 
      !drawnCards.some(drawn => drawn.id === card.id)
    )
    
    const randomCard = availableCards[Math.floor(Math.random() * availableCards.length)]
    const isReversed = Math.random() < 0.3 // 30%概率逆位
    
    const newCard = {
      ...randomCard,
      reversed: isReversed,
      position: this.getCardPosition(drawnCards.length, selectedSpread.id)
    }

    setTimeout(() => {
      const updatedDrawnCards = [...drawnCards, newCard]
      const isComplete = updatedDrawnCards.length === selectedSpread.cardCount
      
      this.setData({
        drawnCards: updatedDrawnCards,
        drawingCard: false,
        drawComplete: isComplete
      })

      if (isComplete) {
        this.generateInterpretation(updatedDrawnCards, selectedSpread)
      }
    }, 1000)
  },

  // 获取牌位含义
  getCardPosition(index, spreadId) {
    const positions = {
      1: ['今日指引'], // 每日一抽
      2: ['过去', '现在', '未来'], // 经典三牌阵
      3: ['您的状态', '对方状态', '关系发展'], // 爱情三角
      4: ['现状', '挑战', '建议'] // 事业指引
    }
    
    return positions[spreadId] ? positions[spreadId][index] : `第${index + 1}张牌`
  },

  // 生成整体解读
  generateInterpretation(cards, spread) {
    let interpretation = ''
    
    switch (spread.id) {
      case 1: // 每日一抽
        const card = cards[0]
        interpretation = `今日的指引牌是「${card.name}」${card.reversed ? '（逆位）' : ''}。\n\n${card.reversed ? card.reversedMeaning : card.uprightMeaning}\n\n建议您今天特别关注${card.keywords.slice(0,2).join('和')}相关的事情，保持开放的心态，关注内在的声音。`
        break
        
      case 2: // 经典三牌阵（过去-现在-未来）
        interpretation = `经典三牌阵为您揭示了事情的完整脉络：\n\n`
        interpretation += `🔙 过去「${cards[0].name}」${cards[0].reversed ? '（逆位）' : ''}\n${cards[0].reversed ? cards[0].reversedMeaning : cards[0].uprightMeaning}\n过去的经历影响着当前的情况，这张牌显示了您之前的状态和经历。\n\n`
        interpretation += `🎆 现在「${cards[1].name}」${cards[1].reversed ? '（逆位）' : ''}\n${cards[1].reversed ? cards[1].reversedMeaning : cards[1].uprightMeaning}\n这是您当前的状态和面临的主要问题，需要特别关注。\n\n`
        interpretation += `🔮 未来「${cards[2].name}」${cards[2].reversed ? '（逆位）' : ''}\n${cards[2].reversed ? cards[2].reversedMeaning : cards[2].uprightMeaning}\n如果按照当前的趋势发展，这是可能的结果和未来的方向。`
        break
        
      case 3: // 爱情三角
        interpretation = `爱情三角为您的感情状况提供指引：\n\n`
        interpretation += `💖 您的状态「${cards[0].name}」${cards[0].reversed ? '（逆位）' : ''}\n${cards[0].reversed ? cards[0].reversedMeaning : cards[0].uprightMeaning}\n\n`
        interpretation += `💝 对方状态「${cards[1].name}」${cards[1].reversed ? '（逆位）' : ''}\n${cards[1].reversed ? cards[1].reversedMeaning : cards[1].uprightMeaning}\n\n`
        interpretation += `💕 关系发展「${cards[2].name}」${cards[2].reversed ? '（逆位）' : ''}\n${cards[2].reversed ? cards[2].reversedMeaning : cards[2].uprightMeaning}\n\n`
        interpretation += `整体来看，这是一个${cards.filter(c => !c.reversed).length >= 2 ? '积极向上' : '需要谨慎对待'}的感情状况。`
        break
        
      case 4: // 事业指引
        interpretation = `事业指引为您的职业发展提供建议：\n\n`
        interpretation += `🏢 现状「${cards[0].name}」${cards[0].reversed ? '（逆位）' : ''}\n${cards[0].reversed ? cards[0].reversedMeaning : cards[0].uprightMeaning}\n\n`
        interpretation += `⚡ 挑战「${cards[1].name}」${cards[1].reversed ? '（逆位）' : ''}\n${cards[1].reversed ? cards[1].reversedMeaning : cards[1].uprightMeaning}\n\n`
        interpretation += `🎆 建议「${cards[2].name}」${cards[2].reversed ? '（逆位）' : ''}\n${cards[2].reversed ? cards[2].reversedMeaning : cards[2].uprightMeaning}\n\n`
        interpretation += `保持耐心和专注，成功需要时间和坚持。`
        break
    }
    
    interpretation += `\n\n🌠 总的来说，这次占卜提醒您要保持开放的心态，相信内在的智慧，勇敢面对挑战。记住，塔罗牌只是指引，最终的选择权仍在您手中。`
    
    this.setData({ overallInterpretation: interpretation })
  },

  // 显示卡片详情
  showCardDetail(e) {
    const card = e.currentTarget.dataset.card
    this.setData({
      selectedCard: card,
      showCardDetail: true
    })
  },

  // 隐藏卡片详情
  hideCardDetail() {
    this.setData({
      showCardDetail: false,
      selectedCard: null
    })
  },

  // 阻止事件冒泡
  stopPropagation() {
    // 空函数，用于阻止事件冒泡
  },

  // 重新占卜
  resetTarot() {
    this.setData({
      selectedSpread: null,
      userQuestion: '',
      drawnCards: [],
      drawComplete: false,
      overallInterpretation: ''
    })
    this.initializeDeck()
  },

  // 分享结果
  shareTarot() {
    wx.showToast({
      title: '分享功能开发中',
      icon: 'none'
    })
  }
})