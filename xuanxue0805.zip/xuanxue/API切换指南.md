# 🔄 API提供商切换指南

## 🚨 当前问题
Coze API频繁出现 `702242002` 错误，建议切换到更稳定的API提供商。

## 🎯 推荐方案

### 1. OpenAI API（最推荐）
**优势**：
- 全球最稳定的AI API
- 支持GPT-3.5/GPT-4
- 文档完善，社区支持好

**申请步骤**：
1. 访问 https://platform.openai.com
2. 注册账号并验证
3. 获取API Key
4. 在 `app.js` 中填入 `openaiApiKey`
5. 修改 `apiProvider: 'openai'`

**费用**：按使用量计费，通常比Coze便宜

### 2. 百度文心一言API
**优势**：
- 国内服务，访问速度快
- 中文理解能力强
- 有免费额度

**申请步骤**：
1. 访问 https://cloud.baidu.com/product/wenxinworkshop
2. 注册百度云账号
3. 创建应用获取API Key
4. 在 `app.js` 中填入 `baiduApiKey`
5. 修改 `apiProvider: 'baidu'`

### 3. 阿里云通义千问API
**优势**：
- 企业级稳定性
- 价格合理
- 支持多种模型

## 🛠️ 快速切换步骤

### 立即使用基础分析模式
1. 关闭AI智能分析开关
2. 使用基础分析模式
3. 功能完全正常

### 申请新API后
1. 在 `app.js` 中填入新的API Key
2. 修改 `apiProvider` 参数
3. 重新编译测试

## 💡 建议
1. **立即**：使用基础分析模式继续开发
2. **短期**：申请OpenAI API作为主要方案
3. **长期**：考虑多API备份机制

## 📞 需要帮助？
如果需要帮助申请API或配置，请告诉我您选择哪个提供商！