// pages/index/index.js
const app = getApp()
const cozeApi = require('../../utils/coze-api')
const dataCollection = require('../../utils/data-collection')

Page({
  data: {
    birthDate: '',
    birthTime: '',
    birthPlace: [],
    birthPlaceText: '',
    userName: '',
    loading: false,
    zodiacInfo: null,
    useAIMode: false, // 默认使用基础分析，避免API问题
    showConstellation: true,
    currentConstellationName: '白羊座'
  },

  onDateChange(e) {
    this.setData({
      birthDate: e.detail.value
    })
  },

  onTimeChange(e) {
    this.setData({
      birthTime: e.detail.value
    })
  },

  onRegionChange(e) {
    const regions = e.detail.value
    this.setData({
      birthPlace: regions,
      birthPlaceText: regions.join('')
    })
  },

  onNameInput(e) {
    this.setData({
      userName: e.detail.value
    })
  },

  toggleAIMode(e) {
    this.setData({
      useAIMode: e.detail.value
    })
  },

  onSubmit() {
    const { birthDate, birthTime, birthPlace, userName, useAIMode } = this.data

    if (!birthDate || !birthTime || birthPlace.length === 0) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      })
      return
    }

    this.setData({ loading: true })

    const userData = {
      birthDate,
      birthTime,
      birthPlace: birthPlace.join(''),
      userName
    }

    if (useAIMode) {
      this.callCozeAPI(userData)
    } else {
      this.useMockData(userData)
    }
  },

  callCozeAPI(userData) {
    console.log('=== 调用Coze API进行星座分析 ===')
    console.log('传递的用户数据:', userData)

    // 设置超时提示
    const timeoutId = setTimeout(() => {
      wx.showToast({
        title: '正在获取数据中...',
        icon: 'loading',
        duration: 2000
      })
    }, 5000)
    
    cozeApi.callZodiacAnalysisWithRetry(userData)
      .then((zodiacInfo) => {
        clearTimeout(timeoutId)
        console.log('Coze API分析结果:', zodiacInfo)
        
        this.setData({
          zodiacInfo,
          loading: false
        })
        
        wx.showToast({
          title: 'AI分析完成',
          icon: 'success'
        })
        
        // 保存用户信息到全局数据
        app.globalData.userInfo = {
          ...userData,
          zodiacInfo
        }

        // 停止轮换并显示用户星座
        this.stopConstellationRotation()
        this.setData({
          currentConstellationName: zodiacInfo.sign
        })
        
        // 收集用户数据（需要用户同意）
        dataCollection.collectUserData('birthInfo', {
          birthDate: userData.birthDate,
          birthTime: userData.birthTime,
          birthPlace: userData.birthPlace,
          zodiacResult: zodiacInfo.sign
        }, '用于提供精确的星座分析服务')
        
        // 收集匿名使用统计
        dataCollection.collectAnonymousData('zodiac_analysis', {
          zodiacSign: zodiacInfo.sign,
          useAIMode: this.data.useAIMode,
          analysisTime: new Date().getTime()
        })
      })
      .catch((error) => {
        clearTimeout(timeoutId)
        console.error('星座分析API调用失败:', error)
        
        let errorMessage = '分析失败，请重试'
        let showModal = false
        
        if (error.message.includes('702242002')) {
          errorMessage = 'Coze服务器暂时繁忙'
          showModal = true
        } else if (error.message.includes('timeout')) {
          errorMessage = '网络超时，请检查网络连接'
        } else if (error.message.includes('网络请求失败')) {
          errorMessage = '网络连接失败'
        } else if (error.message.includes('解析异常')) {
          errorMessage = 'AI响应解析异常，请重试'
        } else if (error.message.includes('Coze API错误')) {
          errorMessage = 'Coze服务异常，请稍后重试'
          showModal = true
        }
        
        this.setData({ loading: false })
        
        if (showModal) {
          wx.showModal({
            title: '温馨提示',
            content: 'Coze AI服务暂时遇到问题，可能的解决方案：\n\n1. 检查网络连接\n2. 稍后重试（5-10分钟）\n3. 或使用基础分析模式体验功能\n\n如问题持续请联系客服！',
            confirmText: '使用模拟数据',
            cancelText: '稍后重试',
            success: (res) => {
              if (res.confirm) {
                this.setData({ useAIMode: false })
                this.onSubmit() // 重新提交，使用模拟数据
              }
            }
          })
        } else {
          wx.showToast({
            title: errorMessage,
            icon: 'none'
          })
        }
      })
  },

  useMockData(userData) {
    console.log('使用模拟数据进行星座分析')
    
    // 模拟API延迟
    setTimeout(() => {
      const mockZodiacInfo = {
        sign: this.calculateZodiacSign(userData.birthDate),
        rising: this.getRandomZodiac(),
        moon: this.getRandomZodiac(),
        element: this.getZodiacElement(this.calculateZodiacSign(userData.birthDate)),
        modality: this.getZodiacModality(this.calculateZodiacSign(userData.birthDate)),
        compatibility: this.getZodiacCompatibility(this.calculateZodiacSign(userData.birthDate)),
        note: '这是基础版测试数据，如需专业版，请开启专业版AI智能分析。'
      }
      
      this.setData({
        zodiacInfo: mockZodiacInfo,
        loading: false
      })
      
      wx.showToast({
        title: '模拟分析完成',
        icon: 'success'
      })
      
              // 保存用户信息到全局数据
        app.globalData.userInfo = {
          ...userData,
          zodiacInfo: mockZodiacInfo
        }

        // 停止轮换并显示用户星座
        this.stopConstellationRotation()
        this.setData({
          currentConstellationName: mockZodiacInfo.sign
        })
    }, 1500)
  },

  calculateZodiacSign(birthDate) {
    const date = new Date(birthDate)
    const month = date.getMonth() + 1
    const day = date.getDate()
    
    if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return '白羊座'
    if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return '金牛座'
    if ((month === 5 && day >= 21) || (month === 6 && day <= 21)) return '双子座'
    if ((month === 6 && day >= 22) || (month === 7 && day <= 22)) return '巨蟹座'
    if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return '狮子座'
    if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return '处女座'
    if ((month === 9 && day >= 23) || (month === 10 && day <= 23)) return '天秤座'
    if ((month === 10 && day >= 24) || (month === 11 && day <= 22)) return '天蝎座'
    if ((month === 11 && day >= 23) || (month === 12 && day <= 21)) return '射手座'
    if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return '摩羯座'
    if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return '水瓶座'
    if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return '双鱼座'
    
    return '白羊座'
  },

  getRandomZodiac() {
    const zodiacs = ['白羊座', '金牛座', '双子座', '巨蟹座', '狮子座', '处女座', '天秤座', '天蝎座', '射手座', '摩羯座', '水瓶座', '双鱼座']
    return zodiacs[Math.floor(Math.random() * zodiacs.length)]
  },

  getZodiacElement(sign) {
    const elements = {
      '白羊座': '火', '狮子座': '火', '射手座': '火',
      '金牛座': '土', '处女座': '土', '摩羯座': '土',
      '双子座': '风', '天秤座': '风', '水瓶座': '风',
      '巨蟹座': '水', '天蝎座': '水', '双鱼座': '水'
    }
    return elements[sign] || '火'
  },

  getZodiacModality(sign) {
    const modalities = {
      '白羊座': '基本', '巨蟹座': '基本', '天秤座': '基本', '摩羯座': '基本',
      '金牛座': '固定', '狮子座': '固定', '天蝎座': '固定', '水瓶座': '固定',
      '双子座': '变动', '处女座': '变动', '射手座': '变动', '双鱼座': '变动'
    }
    return modalities[sign] || '基本'
  },

  getZodiacCompatibility(sign) {
    const compatibility = {
      '白羊座': '与狮子座、射手座最配',
      '金牛座': '与处女座、摩羯座最配',
      '双子座': '与天秤座、水瓶座最配',
      '巨蟹座': '与天蝎座、双鱼座最配',
      '狮子座': '与白羊座、射手座最配',
      '处女座': '与金牛座、摩羯座最配',
      '天秤座': '与双子座、水瓶座最配',
      '天蝎座': '与巨蟹座、双鱼座最配',
      '射手座': '与白羊座、狮子座最配',
      '摩羯座': '与金牛座、处女座最配',
      '水瓶座': '与双子座、天秤座最配',
      '双鱼座': '与巨蟹座、天蝎座最配'
    }
    return compatibility[sign] || '与火象星座最配'
  },

  getZodiacSymbol(sign) {
    const symbols = {
      '白羊座': '♈', '金牛座': '♉', '双子座': '♊', '巨蟹座': '♋',
      '狮子座': '♌', '处女座': '♍', '天秤座': '♎', '天蝎座': '♏',
      '射手座': '♐', '摩羯座': '♑', '水瓶座': '♒', '双鱼座': '♓'
    }
    return symbols[sign] || '⭐'
  },

  // 获取星座在星盘上的位置角度
  getZodiacPosition(sign) {
    const positions = {
      '白羊座': 0,    // 0度（正上方）
      '金牛座': 30,   // 30度
      '双子座': 60,   // 60度
      '巨蟹座': 90,   // 90度（正右方）
      '狮子座': 120,  // 120度
      '处女座': 150,  // 150度
      '天秤座': 180,  // 180度（正下方）
      '天蝎座': 210,  // 210度
      '射手座': 240,  // 240度
      '摩羯座': 270,  // 270度（正左方）
      '水瓶座': 300,  // 300度
      '双鱼座': 330   // 330度
    }
    return positions[sign] || 0
  },

  // 获取星座颜色主题
  getZodiacTheme(sign) {
    const themes = {
      '白羊座': { primary: '#FF6B6B', secondary: '#FFE5E5', gradient: 'linear-gradient(135deg, #FF6B6B 0%, #FF8E8E 100%)' },
      '金牛座': { primary: '#4ECDC4', secondary: '#E8F8F7', gradient: 'linear-gradient(135deg, #4ECDC4 0%, #6EE2D8 100%)' },
      '双子座': { primary: '#45B7D1', secondary: '#E8F4FD', gradient: 'linear-gradient(135deg, #45B7D1 0%, #67C3DD 100%)' },
      '巨蟹座': { primary: '#96CEB4', secondary: '#F0F9F4', gradient: 'linear-gradient(135deg, #96CEB4 0%, #A8D4C2 100%)' },
      '狮子座': { primary: '#FFEAA7', secondary: '#FFF9E8', gradient: 'linear-gradient(135deg, #FFEAA7 0%, #FFECB3 100%)' },
      '处女座': { primary: '#DDA0DD', secondary: '#F5EDF5', gradient: 'linear-gradient(135deg, #DDA0DD 0%, #E4B0E4 100%)' },
      '天秤座': { primary: '#FD79A8', secondary: '#FEF0F6', gradient: 'linear-gradient(135deg, #FD79A8 0%, #FE8FB4 100%)' },
      '天蝎座': { primary: '#6C5CE7', secondary: '#F0EFFF', gradient: 'linear-gradient(135deg, #6C5CE7 0%, #8B7AEA 100%)' },
      '射手座': { primary: '#A29BFE', secondary: '#F2F1FF', gradient: 'linear-gradient(135deg, #A29BFE 0%, #B3AEFE 100%)' },
      '摩羯座': { primary: '#74B9FF', secondary: '#EDF6FF', gradient: 'linear-gradient(135deg, #74B9FF 0%, #8AC4FF 100%)' },
      '水瓶座': { primary: '#00CEC9', secondary: '#E6FFFE', gradient: 'linear-gradient(135deg, #00CEC9 0%, #26D4D1 100%)' },
      '双鱼座': { primary: '#FD79A8', secondary: '#FEF0F6', gradient: 'linear-gradient(135deg, #FD79A8 0%, #FE8FB4 100%)' }
    }
    return themes[sign] || { primary: '#667eea', secondary: '#f0f2f5', gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }
  },

  // 获取星座特性描述
  getZodiacDescription(sign) {
    const descriptions = {
      '白羊座': '热情活力，勇敢直率，天生的领导者',
      '金牛座': '稳重踏实，享受生活，对美有独特品味',
      '双子座': '聪明机智，善于沟通，充满好奇心',
      '巨蟹座': '温柔体贴，重视家庭，情感丰富',
      '狮子座': '自信大方，慷慨热情，天生的表演者',
      '处女座': '细致认真，追求完美，善于分析',
      '天秤座': '优雅和谐，追求平衡，社交能力强',
      '天蝎座': '神秘深邃，意志坚强，洞察力敏锐',
      '射手座': '自由奔放，乐观向上，热爱冒险',
      '摩羯座': '务实稳重，目标明确，责任心强',
      '水瓶座': '独立创新，思想前卫，人道主义',
      '双鱼座': '浪漫梦幻，直觉敏锐，富有同情心'
    }
    return descriptions[sign] || '独特而神秘的星座'
  },

  // 获取星座幸运元素 - 完整版
  getZodiacLucky(sign) {
    const lucky = {
      '白羊座': { 
        number: [6, 7, 18], 
        color: ['红色', '橙色', '金色'], 
        stone: '红宝石',
        flower: '雏菊',
        day: '星期二',
        time: '6:00-8:00',
        direction: '东方',
        metal: '铁',
        perfume: '薄荷香',
        food: ['辣椒', '生姜', '牛肉'],
        activity: '运动健身',
        career: '领导管理'
      },
      '金牛座': { 
        number: [1, 9, 15], 
        color: ['绿色', '粉色', '土色'], 
        stone: '翡翠',
        flower: '玫瑰',
        day: '星期五',
        time: '14:00-16:00',
        direction: '东南',
        metal: '铜',
        perfume: '玫瑰香',
        food: ['蜂蜜', '坚果', '奶制品'],
        activity: '园艺烹饪',
        career: '金融艺术'
      },
      '双子座': { 
        number: [3, 5, 14], 
        color: ['黄色', '银色', '浅蓝'], 
        stone: '玛瑙',
        flower: '薰衣草',
        day: '星期三',
        time: '10:00-12:00',
        direction: '西方',
        metal: '水银',
        perfume: '柠檬香',
        food: ['坚果', '水果', '海鲜'],
        activity: '阅读交流',
        career: '媒体教育'
      },
      '巨蟹座': { 
        number: [2, 8, 21], 
        color: ['白色', '银色', '海蓝'], 
        stone: '珍珠',
        flower: '百合',
        day: '星期一',
        time: '20:00-22:00',
        direction: '北方',
        metal: '银',
        perfume: '茉莉香',
        food: ['牛奶', '海鲜', '米饭'],
        activity: '居家烹饪',
        career: '护理教育'
      },
      '狮子座': { 
        number: [1, 3, 19], 
        color: ['金色', '橙色', '紫色'], 
        stone: '黄水晶',
        flower: '向日葵',
        day: '星期日',
        time: '12:00-14:00',
        direction: '南方',
        metal: '金',
        perfume: '檀香',
        food: ['蜂蜜', '橙子', '牛排'],
        activity: '表演娱乐',
        career: '艺术管理'
      },
      '处女座': { 
        number: [3, 8, 27], 
        color: ['灰色', '米色', '深蓝'], 
        stone: '蓝宝石',
        flower: '满天星',
        day: '星期三',
        time: '8:00-10:00',
        direction: '西南',
        metal: '铂金',
        perfume: '薄荷香',
        food: ['蔬菜', '全麦', '酸奶'],
        activity: '整理规划',
        career: '分析服务'
      },
      '天秤座': { 
        number: [6, 9, 24], 
        color: ['蓝色', '粉色', '淡绿'], 
        stone: '欧泊',
        flower: '康乃馨',
        day: '星期五',
        time: '16:00-18:00',
        direction: '西方',
        metal: '银',
        perfume: '玫瑰香',
        food: ['水果', '甜品', '茶'],
        activity: '社交艺术',
        career: '设计法律'
      },
      '天蝎座': { 
        number: [4, 13, 31], 
        color: ['深红', '黑色', '紫色'], 
        stone: '黑曜石',
        flower: '彼岸花',
        day: '星期二',
        time: '22:00-24:00',
        direction: '北方',
        metal: '钢铁',
        perfume: '神秘香',
        food: ['海鲜', '红酒', '黑巧克力'],
        activity: '深度思考',
        career: '研究调查'
      },
      '射手座': { 
        number: [9, 21, 33], 
        color: ['紫色', '深蓝', '橙色'], 
        stone: '绿松石',
        flower: '紫罗兰',
        day: '星期四',
        time: '18:00-20:00',
        direction: '南方',
        metal: '锡',
        perfume: '薰衣草香',
        food: ['异国料理', '坚果', '葡萄'],
        activity: '旅行探索',
        career: '教育旅游'
      },
      '摩羯座': { 
        number: [3, 22, 26], 
        color: ['黑色', '深绿', '棕色'], 
        stone: '石榴石',
        flower: '梅花',
        day: '星期六',
        time: '4:00-6:00',
        direction: '东北',
        metal: '铅',
        perfume: '木质香',
        food: ['根茎类', '坚果', '黑芝麻'],
        activity: '规划建设',
        career: '管理建筑'
      },
      '水瓶座': { 
        number: [4, 11, 22], 
        color: ['蓝色', '银色', '电光蓝'], 
        stone: '紫水晶',
        flower: '风信子',
        day: '星期六',
        time: '2:00-4:00',
        direction: '西北',
        metal: '铝',
        perfume: '清新香',
        food: ['坚果', '蓝莓', '矿泉水'],
        activity: '创新科技',
        career: '科技公益'
      },
      '双鱼座': { 
        number: [11, 29, 7], 
        color: ['海绿', '紫色', '银白'], 
        stone: '海蓝宝',
        flower: '睡莲',
        day: '星期四',
        time: '0:00-2:00',
        direction: '东南',
        metal: '铂金',
        perfume: '海洋香',
        food: ['海鲜', '紫菜', '薏米'],
        activity: '冥想艺术',
        career: '艺术治疗'
      }
    }
    return lucky[sign] || { 
      number: [7, 14], 
      color: ['金色', '银色'], 
      stone: '水晶',
      flower: '百合',
      day: '星期日',
      time: '12:00-14:00',
      direction: '南方',
      metal: '金',
      perfume: '清香',
      food: ['水果', '蔬菜'],
      activity: '休闲娱乐',
      career: '综合服务'
    }
  },

  // 跳转到运势页面 - 优化版
  goToFortune() {
    // 显示加载提示
    wx.showLoading({
      title: '跳转中...',
      mask: true
    })
    
    // 预设运势页面需要的数据
    const app = getApp()
    const today = new Date()
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
    
    // 将用户信息和今日日期传递给运势页面
    app.globalData.preloadData = {
      userInfo: this.data.zodiacInfo,
      targetDate: todayStr,
      fromPage: 'index'
    }
    
    // 短暂延迟后跳转，给用户更好的体验
    setTimeout(() => {
      wx.hideLoading()
      wx.navigateTo({
        url: '/pages/fortune/fortune',
        success: () => {
          // 跳转成功后的回调
          console.log('成功跳转到运势页面')
        },
        fail: (err) => {
          console.error('跳转失败:', err)
          wx.showToast({
            title: '跳转失败',
            icon: 'none'
          })
        }
      })
    }, 300) // 300ms的缓冲时间
  },

  // 导航到树洞页面
  goToTreeHole() {
    wx.navigateTo({
      url: '/pages/treehole/treehole'
    })
  },

  // 导航到塔罗牌页面
  goToTarot() {
    wx.navigateTo({
      url: '/pages/tarot/tarot'
    })
  },

  // 导航到星座配对页面
  goToMatching() {
    wx.navigateTo({
      url: '/pages/matching/matching'
    })
  },

  // 导航到个人档案页面
  goToProfile() {
    wx.navigateTo({
      url: '/pages/profile/profile'
    })
  },

  // 获取星座符号
  getZodiacSymbol(sign) {
    const symbols = {
      '白羊座': '♈', '金牛座': '♉', '双子座': '♊', '巨蟹座': '♋',
      '狮子座': '♌', '处女座': '♍', '天秤座': '♎', '天蝎座': '♏',
      '射手座': '♐', '摩羯座': '♑', '水瓶座': '♒', '双鱼座': '♓'
    }
    return symbols[sign] || '⭐'
  },

  // 显示星盘详细解读
  showStarChartDetail() {
    wx.navigateTo({
      url: '/pages/chart-detail/chart-detail'
    })
  },

  // 显示图表可视化
  showChartVisualization() {
    wx.navigateTo({
      url: '/chart-package/pages/chart-visualization/chart-visualization'
    })
  },

  // 获取元素描述
  getElementDescription(element) {
    const descriptions = {
      '火': '火象星座充满热情和活力，行动力强，喜欢冒险和挑战。',
      '土': '土象星座务实稳重，注重现实，有很强的责任感和执行力。',
      '风': '风象星座思维活跃，善于交流，追求自由和新鲜事物。',
      '水': '水象星座情感丰富，直觉敏锐，富有同情心和想象力。'
    }
    return descriptions[element] || '独特的能量特质。'
  },

  // 获取模式描述
  getModalityDescription(modality) {
    const descriptions = {
      '基本': '基本宫星座善于开创和领导，有很强的主动性和开拓精神。',
      '固定': '固定宫星座坚持不懈，有很强的意志力和持久力。',
      '变动': '变动宫星座适应性强，灵活多变，善于调节和沟通。'
    }
    return descriptions[modality] || '独特的行为模式。'
  },

  // 切换到用户对应的星座背景
  switchToUserConstellation(zodiacSign) {
    const zodiacIndex = this.getZodiacIndex(zodiacSign)
    
    // 获取星座背景组件实例
    const constellationBg = this.selectComponent('constellation-background')
    if (constellationBg) {
      // 停止自动切换
      constellationBg.stopAutoSwitch()
      
      // 延迟切换到用户星座，让用户看到切换效果
      setTimeout(() => {
        constellationBg.switchToConstellation(zodiacIndex)
      }, 1000)
    }
  },

  // 获取星座对应的索引
  getZodiacIndex(zodiacSign) {
    const zodiacOrder = [
      '白羊座', '金牛座', '双子座', '巨蟹座', '狮子座', '处女座',
      '天秤座', '天蝎座', '射手座', '摩羯座', '水瓶座', '双鱼座'
    ]
    const index = zodiacOrder.indexOf(zodiacSign)
    return index >= 0 ? index : 0
  },

  // 开始星座背景轮换
  startConstellationRotation() {
    const zodiacNames = [
      '白羊座', '金牛座', '双子座', '巨蟹座', '狮子座', '处女座',
      '天秤座', '天蝎座', '射手座', '摩羯座', '水瓶座', '双鱼座'
    ]
    
    let currentIndex = 0
    this.constellationTimer = setInterval(() => {
      // 只在没有分析结果时才轮换
      if (!this.data.zodiacInfo) {
        this.setData({
          currentConstellationName: zodiacNames[currentIndex]
        })
        currentIndex = (currentIndex + 1) % zodiacNames.length
      }
    }, 5000) // 5秒切换一次
  },

  // 停止星座背景轮换
  stopConstellationRotation() {
    if (this.constellationTimer) {
      clearInterval(this.constellationTimer)
      this.constellationTimer = null
    }
  },

  onLoad() {
    console.log('首页加载')
    // 开始星座背景轮换
    this.startConstellationRotation()
  },

  onUnload() {
    // 清理定时器
    this.stopConstellationRotation()
  }
})