/**
 * 用户数据收集模块
 * 符合《个人信息保护法》和微信小程序规范
 */

const app = getApp()

/**
 * 数据收集配置
 */
const DATA_COLLECTION_CONFIG = {
  // 需要用户同意的数据类型
  SENSITIVE_DATA: [
    'location',      // 位置信息
    'birthInfo',     // 出生信息
    'personalPrefs'  // 个人偏好
  ],
  
  // 匿名统计数据（无需特别同意）
  ANONYMOUS_DATA: [
    'appUsage',      // 应用使用统计
    'featureUsage',  // 功能使用统计
    'errorLogs'      // 错误日志
  ]
}

/**
 * 检查用户是否已同意数据收集
 * @param {string} dataType - 数据类型
 * @returns {boolean} 是否已同意
 */
function hasUserConsent(dataType) {
  const consent = wx.getStorageSync('userDataConsent') || {}
  return consent[dataType] === true
}

/**
 * 请求用户数据收集同意
 * @param {string} dataType - 数据类型
 * @param {string} purpose - 收集目的
 * @returns {Promise<boolean>} 用户是否同意
 */
function requestUserConsent(dataType, purpose) {
  return new Promise((resolve) => {
    const messages = {
      'location': '为了提供更准确的星座分析，我们需要获取您的出生地信息',
      'birthInfo': '为了进行星座和运势分析，我们需要收集您的出生日期和时间',
      'personalPrefs': '为了提供个性化服务，我们希望了解您的使用偏好'
    }
    
    wx.showModal({
      title: '数据使用授权',
      content: `${messages[dataType] || purpose}\n\n我们承诺：\n• 仅用于改善服务体验\n• 不会泄露给第三方\n• 您可随时撤销授权`,
      confirmText: '同意',
      cancelText: '拒绝',
      success: (res) => {
        const consent = wx.getStorageSync('userDataConsent') || {}
        consent[dataType] = res.confirm
        consent.timestamp = new Date().getTime()
        wx.setStorageSync('userDataConsent', consent)
        
        resolve(res.confirm)
      }
    })
  })
}

/**
 * 收集用户数据（需要用户同意）
 * @param {string} dataType - 数据类型
 * @param {Object} data - 要收集的数据
 * @param {string} purpose - 收集目的
 */
async function collectUserData(dataType, data, purpose) {
  // 检查是否需要用户同意
  if (DATA_COLLECTION_CONFIG.SENSITIVE_DATA.includes(dataType)) {
    const hasConsent = hasUserConsent(dataType)
    
    if (!hasConsent) {
      const granted = await requestUserConsent(dataType, purpose)
      if (!granted) {
        console.log('用户拒绝数据收集:', dataType)
        return false
      }
    }
  }
  
  // 收集数据
  const collectedData = {
    type: dataType,
    data: data,
    timestamp: new Date().getTime(),
    userId: generateAnonymousUserId(),
    purpose: purpose
  }
  
  // 存储到本地
  const existingData = wx.getStorageSync('collectedData') || []
  existingData.push(collectedData)
  wx.setStorageSync('collectedData', existingData)
  
  // 如果有网络，上传到服务器
  uploadDataToServer(collectedData)
  
  return true
}

/**
 * 收集匿名统计数据
 * @param {string} eventType - 事件类型
 * @param {Object} eventData - 事件数据
 */
function collectAnonymousData(eventType, eventData) {
  const anonymousData = {
    event: eventType,
    data: eventData,
    timestamp: new Date().getTime(),
    sessionId: getSessionId(),
    appVersion: '1.0.0'
  }
  
  // 存储到本地
  const existingStats = wx.getStorageSync('anonymousStats') || []
  existingStats.push(anonymousData)
  
  // 只保留最近1000条记录
  if (existingStats.length > 1000) {
    existingStats.splice(0, existingStats.length - 1000)
  }
  
  wx.setStorageSync('anonymousStats', existingStats)
  
  // 批量上传统计数据
  if (existingStats.length % 10 === 0) {
    uploadAnonymousStats()
  }
}

/**
 * 生成匿名用户ID
 * @returns {string} 匿名用户ID
 */
function generateAnonymousUserId() {
  let userId = wx.getStorageSync('anonymousUserId')
  if (!userId) {
    userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
    wx.setStorageSync('anonymousUserId', userId)
  }
  return userId
}

/**
 * 获取会话ID
 * @returns {string} 会话ID
 */
function getSessionId() {
  let sessionId = wx.getStorageSync('currentSessionId')
  if (!sessionId) {
    sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
    wx.setStorageSync('currentSessionId', sessionId)
  }
  return sessionId
}

/**
 * 上传数据到服务器
 * @param {Object} data - 要上传的数据
 */
function uploadDataToServer(data) {
  // 这里应该是您的服务器API
  const serverUrl = 'https://your-server.com/api/collect'
  
  wx.request({
    url: serverUrl,
    method: 'POST',
    header: {
      'Content-Type': 'application/json'
    },
    data: {
      ...data,
      appId: 'xuanxue_miniprogram',
      contact: 'kimxcx@163.com'
    },
    success: (res) => {
      console.log('数据上传成功:', res)
    },
    fail: (error) => {
      console.log('数据上传失败，将在下次尝试:', error)
    }
  })
}

/**
 * 批量上传匿名统计数据
 */
function uploadAnonymousStats() {
  const stats = wx.getStorageSync('anonymousStats') || []
  if (stats.length === 0) return
  
  wx.request({
    url: 'https://your-server.com/api/stats',
    method: 'POST',
    header: {
      'Content-Type': 'application/json'
    },
    data: {
      stats: stats,
      appId: 'xuanxue_miniprogram'
    },
    success: (res) => {
      console.log('统计数据上传成功')
      // 清空已上传的数据
      wx.setStorageSync('anonymousStats', [])
    },
    fail: (error) => {
      console.log('统计数据上传失败:', error)
    }
  })
}

/**
 * 用户撤销数据收集同意
 * @param {string} dataType - 数据类型
 */
function revokeConsent(dataType) {
  const consent = wx.getStorageSync('userDataConsent') || {}
  consent[dataType] = false
  wx.setStorageSync('userDataConsent', consent)
  
  wx.showToast({
    title: '已撤销授权',
    icon: 'success'
  })
}

/**
 * 查看用户数据收集状态
 * @returns {Object} 数据收集状态
 */
function getDataCollectionStatus() {
  return {
    consent: wx.getStorageSync('userDataConsent') || {},
    collectedData: wx.getStorageSync('collectedData') || [],
    anonymousStats: wx.getStorageSync('anonymousStats') || []
  }
}

/**
 * 清除所有收集的数据
 */
function clearAllCollectedData() {
  wx.removeStorageSync('collectedData')
  wx.removeStorageSync('anonymousStats')
  wx.removeStorageSync('userDataConsent')
  wx.removeStorageSync('anonymousUserId')
  
  wx.showToast({
    title: '数据已清除',
    icon: 'success'
  })
}

module.exports = {
  collectUserData,
  collectAnonymousData,
  hasUserConsent,
  requestUserConsent,
  revokeConsent,
  getDataCollectionStatus,
  clearAllCollectedData
}