/**
 * Coze工作流API调用模块
 * 提供更稳定的数据结构和更好的错误处理
 */

const app = getApp()

/**
 * 调用Coze工作流API进行星座分析
 * @param {Object} userData - 用户数据
 * @returns {Promise} 分析结果
 */
function callZodiacWorkflow(userData) {
  return new Promise((resolve, reject) => {
    console.log('调用Coze工作流API进行星座分析:', userData)
    
    const requestData = {
      // 工作流ID
      workflow_id: app.globalData.zodiacWorkflowId,
      // 结构化参数
      parameters: {
        birth_date: userData.birthDate,
        birth_time: userData.birthTime,
        birth_place: userData.birthPlace,
        user_name: userData.name || '用户'
      }
    }
    
    wx.request({
      url: 'https://api.coze.cn/open_api/v2/workflows/run',
      method: 'POST',
      header: {
        'Authorization': `Bearer ${app.globalData.cozeApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: requestData,
      timeout: app.globalData.apiTimeout || 30000,
      success: (res) => {
        console.log('工作流API响应:', res)
        
        if (res.statusCode === 200 && res.data) {
          try {
            const result = parseWorkflowResponse(res.data)
            resolve(result)
          } catch (parseError) {
            console.error('工作流响应解析失败:', parseError)
            reject(new Error('数据解析失败'))
          }
        } else {
          console.error('工作流API调用失败:', res)
          reject(new Error(`API调用失败: ${res.statusCode}`))
        }
      },
      fail: (error) => {
        console.error('工作流API网络错误:', error)
        if (error.errMsg && error.errMsg.includes('timeout')) {
          reject(new Error('请求超时，请检查网络连接'))
        } else {
          reject(new Error('网络请求失败'))
        }
      }
    })
  })
}

/**
 * 调用Coze工作流API进行运势预测
 * @param {string} targetDate - 目标日期
 * @param {Object} userInfo - 用户信息
 * @returns {Promise} 预测结果
 */
function callFortuneWorkflow(targetDate, userInfo) {
  return new Promise((resolve, reject) => {
    console.log('调用Coze工作流API进行运势预测:', targetDate, userInfo)
    
    const requestData = {
      workflow_id: app.globalData.fortuneWorkflowId,
      parameters: {
        target_date: targetDate,
        zodiac_sign: userInfo.zodiacInfo?.sign || userInfo.sign,
        birth_date: userInfo.birthDate,
        birth_time: userInfo.birthTime,
        birth_place: userInfo.birthPlace
      }
    }
    
    wx.request({
      url: 'https://api.coze.cn/open_api/v2/workflows/run',
      method: 'POST',
      header: {
        'Authorization': `Bearer ${app.globalData.cozeApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: requestData,
      timeout: app.globalData.apiTimeout || 30000,
      success: (res) => {
        console.log('运势工作流API响应:', res)
        
        if (res.statusCode === 200 && res.data) {
          try {
            const result = parseFortuneWorkflowResponse(res.data)
            resolve(result)
          } catch (parseError) {
            console.error('运势工作流响应解析失败:', parseError)
            reject(new Error('数据解析失败'))
          }
        } else {
          console.error('运势工作流API调用失败:', res)
          reject(new Error(`API调用失败: ${res.statusCode}`))
        }
      },
      fail: (error) => {
        console.error('运势工作流API网络错误:', error)
        if (error.errMsg && error.errMsg.includes('timeout')) {
          reject(new Error('请求超时，请检查网络连接'))
        } else {
          reject(new Error('网络请求失败'))
        }
      }
    })
  })
}

/**
 * 解析工作流星座分析响应
 * @param {Object} responseData - 工作流响应数据
 * @returns {Object} 解析后的星座信息
 */
function parseWorkflowResponse(responseData) {
  console.log('解析工作流星座响应:', responseData)
  
  // 工作流API通常返回更结构化的数据
  let result = {}
  
  if (responseData.data) {
    // 直接从data字段获取结果
    result = responseData.data
  } else if (responseData.output) {
    // 从output字段获取结果
    result = responseData.output
  } else if (responseData.result) {
    // 从result字段获取结果
    result = responseData.result
  }
  
  // 标准化数据格式
  return {
    sign: result.星座 || result.zodiac_sign || result.sign || '白羊座',
    rising: result.上升星座 || result.rising_sign || result.rising || '未知',
    moon: result.月亮星座 || result.moon_sign || result.moon || '未知',
    element: result.星座元素 || result.zodiac_element || result.element || '火',
    modality: result.星座模式 || result.zodiac_modality || result.modality || '基本',
    compatibility: result.兼容性 || result.compatibility || result.zodiac_compatibility || '良好',
    note: result.备注 || result.note || result.remark || 'AI分析完成'
  }
}

/**
 * 解析工作流运势预测响应
 * @param {Object} responseData - 工作流响应数据
 * @returns {Object} 解析后的运势信息
 */
function parseFortuneWorkflowResponse(responseData) {
  console.log('解析工作流运势响应:', responseData)
  
  let result = {}
  
  if (responseData.data) {
    result = responseData.data
  } else if (responseData.output) {
    result = responseData.output
  } else if (responseData.result) {
    result = responseData.result
  }
  
  return {
    targetDate: result.目标日时间 || result.target_date || result.date,
    fortune: result.目标日运势 || result.fortune || result.prediction,
    color: result.目标日穿衣颜色推荐 || result.lucky_color || result.color,
    accessory: result.目标日配饰选择 || result.lucky_accessory || result.accessory,
    note: result.备注 || result.note || result.remark || 'AI预测完成',
    // 扩展字段
    love: result.爱情运势 || result.love_fortune || '',
    career: result.事业运势 || result.career_fortune || '',
    money: result.财运 || result.money_fortune || '',
    health: result.健康运势 || result.health_fortune || '',
    score: result.运势评分 || result.fortune_score || 4,
    luckyNumber: result.幸运数字 || result.lucky_number || Math.floor(Math.random() * 99) + 1,
    luckyTime: result.幸运时间 || result.lucky_time || '10:00-12:00'
  }
}

/**
 * 重试机制的工作流API调用
 * @param {Object} userData - 用户数据
 * @returns {Promise} 分析结果
 */
function callZodiacWorkflowWithRetry(userData) {
  return retryWorkflowCall(() => callZodiacWorkflow(userData), 3)
}

/**
 * 重试机制的运势工作流API调用
 * @param {string} targetDate - 目标日期
 * @param {Object} userInfo - 用户信息
 * @returns {Promise} 预测结果
 */
function callFortuneWorkflowWithRetry(targetDate, userInfo) {
  return retryWorkflowCall(() => callFortuneWorkflow(targetDate, userInfo), 3)
}

/**
 * 工作流API重试机制
 * @param {Function} apiCall - API调用函数
 * @param {number} maxRetries - 最大重试次数
 * @returns {Promise} API调用结果
 */
function retryWorkflowCall(apiCall, maxRetries = 3) {
  return new Promise((resolve, reject) => {
    let retryCount = 0
    
    function attemptCall() {
      apiCall()
        .then(resolve)
        .catch((error) => {
          retryCount++
          console.log(`工作流API调用失败，重试次数: ${retryCount}/${maxRetries}`, error)
          
          if (retryCount < maxRetries) {
            // 指数退避延迟
            const delay = Math.pow(2, retryCount) * 1000
            setTimeout(attemptCall, delay)
          } else {
            reject(error)
          }
        })
    }
    
    attemptCall()
  })
}

module.exports = {
  callZodiacWorkflowWithRetry,
  callFortuneWorkflowWithRetry,
  callZodiacWorkflow,
  callFortuneWorkflow
}