// 星座数据可视化页面
import * as echarts from '../../components/ec-canvas/echarts'
const app = getApp()

Page({
  data: {
    zodiacInfo: {},
    overallScore: 0,
    radarData: [],
    barChartData: [],
    detailData: [],
    ec: {
      onInit: null
    }
  },

  onLoad(options) {
    console.log('数据可视化页面加载')
    
    // 获取用户信息
    const globalUserInfo = app.globalData.userInfo
    if (globalUserInfo && globalUserInfo.zodiacInfo) {
      this.setData({
        zodiacInfo: globalUserInfo.zodiacInfo
      })
      
      // 生成图表数据
      this.generateChartData()
      
      // 初始化ECharts
      this.initChart()
    }
  },

  // 初始化ECharts
  initChart() {
    this.setData({
      ec: {
        onInit: this.initRadarChart.bind(this)
      }
    })
  },

  // 初始化雷达图
  initRadarChart(canvas, width, height, dpr) {
    const chart = echarts.init(canvas, null, {
      width: width,
      height: height,
      devicePixelRatio: dpr
    })
    canvas.setChart(chart)

    const option = this.getRadarOption()
    chart.setOption(option)
    return chart
  },

  // 获取雷达图配置
  getRadarOption() {
    const zodiacInfo = this.data.zodiacInfo
    const sign = zodiacInfo.sign
    const zodiacScores = this.getZodiacScores(sign)

    return {
      backgroundColor: 'rgba(26, 26, 46, 0.8)',
      title: {
        text: '今日运势',
        left: 'center',
        top: 15,
        textStyle: { 
          color: 'rgba(255, 255, 255, 0.9)', 
          fontSize: 18,
          fontWeight: '500'
        }
      },
      radar: {
        indicator: [
          { name: '爱情', max: 100 },
          { name: '事业', max: 100 },
          { name: '财富', max: 100 },
          { name: '健康', max: 100 },
          { name: '幸运', max: 100 }
        ],
        shape: 'circle',
        splitNumber: 4,
        center: ['50%', '50%'],
        radius: '55%',
        axisLine: { 
          lineStyle: { 
            color: 'rgba(255, 255, 255, 0.2)',
            width: 1
          } 
        },
        splitLine: { 
          lineStyle: { 
            color: 'rgba(255, 255, 255, 0.1)',
            width: 1
          } 
        },
        splitArea: { 
          show: true,
          areaStyle: { 
            color: [
              'rgba(102, 126, 234, 0.05)', 
              'rgba(102, 126, 234, 0.1)',
              'rgba(102, 126, 234, 0.15)'
            ]
          } 
        },
        name: {
          textStyle: {
            color: 'rgba(255, 255, 255, 0.9)',
            fontSize: 13,
            fontWeight: '500',
            backgroundColor: 'rgba(26, 26, 46, 0.8)',
            borderRadius: 4,
            padding: [3, 6],
            borderColor: 'rgba(173, 216, 230, 0.4)',
            borderWidth: 1
          }
        }
      },
      series: [{
        name: '今日星座运势',
        type: 'radar',
        data: [{
          value: [
            zodiacScores.love || 85,
            zodiacScores.career || 70, 
            zodiacScores.money || 65,
            zodiacScores.health || 90,
            zodiacScores.luck || 75
          ],
          name: '运势雷达',
          areaStyle: {
            color: 'rgba(173, 216, 230, 0.25)'
          },
          lineStyle: {
            color: 'rgba(173, 216, 230, 0.8)',
            width: 3
          },
          itemStyle: {
            color: '#ADD8E6',
            borderColor: 'rgba(255, 255, 255, 0.8)',
            borderWidth: 2
          },
          symbol: 'circle',
          symbolSize: 6
        }]
      }]
    }
  },

  // 生成图表数据
  generateChartData() {
    const zodiacInfo = this.data.zodiacInfo
    const sign = zodiacInfo.sign
    
    // 根据星座生成不同的数据
    const zodiacScores = this.getZodiacScores(sign)
    
    // 雷达图数据（更新为运势相关）
    const radarData = [
      { name: '爱情', score: zodiacScores.love || 85, angle: 0 },
      { name: '事业', score: zodiacScores.career || 70, angle: 72 },
      { name: '财富', score: zodiacScores.money || 65, angle: 144 },
      { name: '健康', score: zodiacScores.health || 90, angle: 216 },
      { name: '幸运', score: zodiacScores.luck || 75, angle: 288 }
    ]
    
    // 柱状图数据（未来6个月运势趋势）
    const barChartData = this.generateMonthlyFortune(zodiacScores)
    
    // 详细数据（更新为运势相关）
    const detailData = [
      { name: '爱情运势', score: Math.round(zodiacScores.love / 10), percentage: zodiacScores.love, color: '#ff9966' },
      { name: '事业运势', score: Math.round(zodiacScores.career / 10), percentage: zodiacScores.career, color: '#667eea' },
      { name: '财富运势', score: Math.round(zodiacScores.money / 10), percentage: zodiacScores.money, color: '#4ecdc4' },
      { name: '健康运势', score: Math.round(zodiacScores.health / 10), percentage: zodiacScores.health, color: '#ff6b7d' },
      { name: '幸运指数', score: Math.round(zodiacScores.luck / 10), percentage: zodiacScores.luck, color: '#764ba2' }
    ]
    
    // 计算综合评分
    const overallScore = Math.round((zodiacScores.love + zodiacScores.career + 
                                   zodiacScores.money + zodiacScores.health + 
                                   zodiacScores.luck) / 5)
    
    this.setData({
      radarData,
      barChartData,
      detailData,
      overallScore
    })
  },

  // 根据星座获取评分
  getZodiacScores(sign) {
    const scores = {
      '白羊座': { 
        leadership: 9, creativity: 8, communication: 7, emotional: 6, execution: 9, adaptability: 7, 
        overall: 8, career: 85, love: 78, money: 72, health: 88, luck: 82 
      },
      '金牛座': { 
        leadership: 6, creativity: 7, communication: 6, emotional: 8, execution: 9, adaptability: 5, 
        overall: 7, career: 88, love: 85, money: 92, health: 82, luck: 75 
      },
      '双子座': { 
        leadership: 7, creativity: 9, communication: 10, emotional: 6, execution: 6, adaptability: 9, 
        overall: 8, career: 75, love: 70, money: 68, health: 85, luck: 88 
      },
      '巨蟹座': { 
        leadership: 6, creativity: 8, communication: 7, emotional: 10, execution: 7, adaptability: 6, 
        overall: 7, career: 68, love: 92, money: 75, health: 90, luck: 78 
      },
      '狮子座': { 
        leadership: 10, creativity: 9, communication: 8, emotional: 7, execution: 8, adaptability: 6, 
        overall: 8, career: 92, love: 85, money: 80, health: 85, luck: 88 
      },
      '处女座': { 
        leadership: 7, creativity: 7, communication: 8, emotional: 7, execution: 10, adaptability: 7, 
        overall: 8, career: 95, love: 65, money: 88, health: 92, luck: 72 
      },
      '天秤座': { 
        leadership: 7, creativity: 8, communication: 9, emotional: 8, execution: 6, adaptability: 8, 
        overall: 8, career: 78, love: 95, money: 82, health: 80, luck: 85 
      },
      '天蝎座': { 
        leadership: 8, creativity: 8, communication: 7, emotional: 9, execution: 9, adaptability: 7, 
        overall: 8, career: 88, love: 88, money: 85, health: 88, luck: 80 
      },
      '射手座': { 
        leadership: 8, creativity: 9, communication: 8, emotional: 7, execution: 7, adaptability: 9, 
        overall: 8, career: 75, love: 72, money: 70, health: 95, luck: 92 
      },
      '摩羯座': { 
        leadership: 9, creativity: 6, communication: 7, emotional: 6, execution: 10, adaptability: 6, 
        overall: 7, career: 98, love: 65, money: 95, health: 78, luck: 70 
      },
      '水瓶座': { 
        leadership: 8, creativity: 10, communication: 8, emotional: 7, execution: 7, adaptability: 9, 
        overall: 8, career: 82, love: 75, money: 78, health: 85, luck: 90 
      },
      '双鱼座': { 
        leadership: 6, creativity: 10, communication: 7, emotional: 10, execution: 6, adaptability: 8, 
        overall: 8, career: 68, love: 95, money: 72, health: 88, luck: 85 
      }
    }
    return scores[sign] || scores['白羊座']
  },

  // 生成未来6个月的运势数据（基于星座特质的周期性变化）
  generateMonthlyFortune(zodiacScores) {
    const currentMonth = new Date().getMonth()
    const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
    const colors = [
      'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', 
      'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
      'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)'
    ]
    
    const barChartData = []
    
    // 基础运势（当前星座评分的平均值）
    const baseScore = Math.round((zodiacScores.love + zodiacScores.career + 
                                zodiacScores.money + zodiacScores.health + 
                                zodiacScores.luck) / 5)
    
    for (let i = 0; i < 6; i++) {
      const monthIndex = (currentMonth + i) % 12
      const monthName = months[monthIndex]
      
      // 基于月份和星座特质计算运势波动
      let monthlyBonus = 0
      
      // 春季星座在春天运势更好
      if ((monthIndex >= 2 && monthIndex <= 4) && 
          ['白羊座', '金牛座', '双子座'].includes(this.data.zodiacInfo.sign)) {
        monthlyBonus = 10
      }
      // 夏季星座在夏天运势更好  
      else if ((monthIndex >= 5 && monthIndex <= 7) && 
               ['巨蟹座', '狮子座', '处女座'].includes(this.data.zodiacInfo.sign)) {
        monthlyBonus = 10
      }
      // 秋季星座在秋天运势更好
      else if ((monthIndex >= 8 && monthIndex <= 10) && 
               ['天秤座', '天蝎座', '射手座'].includes(this.data.zodiacInfo.sign)) {
        monthlyBonus = 10
      }
      // 冬季星座在冬天运势更好
      else if ((monthIndex >= 11 || monthIndex <= 1) && 
               ['摩羯座', '水瓶座', '双鱼座'].includes(this.data.zodiacInfo.sign)) {
        monthlyBonus = 10
      }
      
      // 添加一些自然波动（-5到+5）
      const naturalVariation = Math.floor(Math.random() * 11) - 5
      
      // 计算最终分数（60-95之间）
      const finalScore = Math.max(60, Math.min(95, baseScore + monthlyBonus + naturalVariation))
      
      barChartData.push({
        month: monthName,
        value: finalScore,
        height: finalScore - 10, // 调整显示高度
        color: colors[i],
        isCurrentSeason: monthlyBonus > 0
      })
    }
    
    return barChartData
  },

  // 返回上一页
  goBack() {
    wx.navigateBack()
  },

  // 分享图表
  shareChart() {
    const { zodiacInfo, overallScore } = this.data
    
    wx.showActionSheet({
      itemList: ['分享给好友', '保存到相册', '生成分享图片'],
      success: (res) => {
        switch(res.tapIndex) {
          case 0:
            // 分享给好友
            this.shareToFriend()
            break
          case 1:
            // 保存到相册
            this.saveToAlbum()
            break
          case 2:
            // 生成分享图片
            this.generateShareImage()
            break
        }
      }
    })
  },

  // 分享给好友
  shareToFriend() {
    const { zodiacInfo, overallScore } = this.data
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
    
    // 触发分享
    wx.showToast({
      title: '点击右上角分享',
      icon: 'none',
      duration: 2000
    })
  },

  // 保存到相册
  saveToAlbum() {
    wx.showLoading({ title: '正在生成图片...' })
    
    // 模拟生成图片过程
    setTimeout(() => {
      wx.hideLoading()
      wx.showModal({
        title: '功能开发中',
        content: '图片保存功能正在开发中，敬请期待！',
        showCancel: false,
        confirmText: '知道了'
      })
    }, 1500)
  },

  // 生成分享图片
  generateShareImage() {
    const { zodiacInfo, overallScore } = this.data
    
    wx.showLoading({ title: '生成中...' })
    
    // 模拟生成分享图片
    setTimeout(() => {
      wx.hideLoading()
      wx.showModal({
        title: '分享图片',
        content: `${zodiacInfo.sign || '神秘星座'}的运势分析图片已生成！综合评分: ${overallScore}分`,
        confirmText: '查看效果',
        cancelText: '稍后再说',
        success: (res) => {
          if (res.confirm) {
            wx.showToast({
              title: '功能完善中',
              icon: 'none'
            })
          }
        }
      })
    }, 2000)
  },

  // 分享功能
  onShareAppMessage() {
    const { zodiacInfo, overallScore } = this.data
    return {
      title: `🌟 ${zodiacInfo.sign || '神秘星座'}的运势分析报告 - 综合评分${overallScore}分`,
      path: '/pages/index/index',
      imageUrl: '' // 可以后续添加分享图片
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    const { zodiacInfo, overallScore } = this.data
    return {
      title: `探索${zodiacInfo.sign || '星座'}的神秘运势 ✨ 综合评分${overallScore}分！`,
      imageUrl: '' // 可以后续添加分享图片
    }
  }
})