// pages/treehole/treehole.js
const app = getApp()

Page({
  data: {
    postContent: '',
    posting: false,
    userZodiac: '',
    posts: [],
    filteredPosts: [],
    currentFilter: 'all',
    sortType: 'time', // 'time' 或 'heat'
    followingUsers: ['白羊座', '天秤座'], // 模拟关注的用户星座
    userLocation: '北京' // 模拟用户位置
  },

  onLoad() {
    // 获取用户星座信息
    const userInfo = app.globalData.userInfo
    if (userInfo && userInfo.zodiacInfo) {
      this.setData({
        userZodiac: userInfo.zodiacInfo.sign
      })
    }
    
    // 加载树洞数据
    this.loadPosts()
  },

  // 加载树洞帖子
  loadPosts() {
    // 模拟数据，确保不同筛选条件有明显区别
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    
    const mockPosts = [
      // 热门帖子 - 关注用户(白羊座) - 同城
      {
        id: 1,
        content: '今天心情特别好！刚刚收到了心仪公司的offer，感觉所有的努力都值得了 ✨',
        zodiac: '白羊座', // 关注用户 + 同城
        createTime: new Date(today.getTime() + 2 * 60 * 60 * 1000),
        likeCount: 25,
        commentCount: 12,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 超级热门帖子 - 同城用户
      {
        id: 2,
        content: '昨天和朋友一起看了星空，突然觉得自己的烦恼都很渺小。宇宙这么大，我们都是独特的存在 🌌',
        zodiac: '水瓶座', // 同城用户
        createTime: new Date(today.getTime() - 12 * 60 * 60 * 1000),
        likeCount: 45,
        commentCount: 23,
        liked: true,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 关注用户的热门帖子
      {
        id: 3,
        content: '刚刚和暗恋的人表白了...被拒绝了。心情很复杂，但至少没有遗憾了吧 💔',
        zodiac: '天秤座', // 关注用户
        createTime: new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000),
        likeCount: 18,
        commentCount: 15,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 同城用户的普通帖子
      {
        id: 4,
        content: '今天终于把拖了很久的书看完了！推荐《小王子》给大家 📖',
        zodiac: '双子座', // 同城用户
        createTime: new Date(today.getTime() + 6 * 60 * 60 * 1000),
        likeCount: 8,
        commentCount: 3,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 外地用户的热门帖子（不在附近）
      {
        id: 5,
        content: '终于完成了人生第一次马拉松！42公里的坚持让我明白了什么叫做突破自己 🏃‍♀️',
        zodiac: '射手座', // 外地用户
        createTime: new Date(today.getTime() - 3 * 24 * 60 * 60 * 1000),
        likeCount: 35,
        commentCount: 18,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 最新帖子 - 关注用户
      {
        id: 6,
        content: '准备开始新的健身计划！希望能坚持下去 💪',
        zodiac: '白羊座', // 关注用户 + 同城
        createTime: new Date(Date.now() - 30 * 60 * 1000), // 30分钟前
        likeCount: 3,
        commentCount: 1,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 最新帖子 - 外地普通用户
      {
        id: 7,
        content: '今天天气真好，心情也跟着好起来了 ☀️',
        zodiac: '巨蟹座', // 外地用户
        createTime: new Date(Date.now() - 60 * 60 * 1000), // 1小时前
        likeCount: 2,
        commentCount: 0,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 同城用户的最新帖子
      {
        id: 8,
        content: '刚刚在咖啡厅遇到一只超可爱的猫咪，瞬间被治愈了 🐱',
        zodiac: '狮子座', // 同城用户
        createTime: new Date(Date.now() - 90 * 60 * 1000), // 90分钟前
        likeCount: 12,
        commentCount: 5,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 低互动帖子（不会出现在热门）
      {
        id: 9,
        content: '今天又是平淡的一天...',
        zodiac: '摩羯座', // 外地用户
        createTime: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000),
        likeCount: 1,
        commentCount: 0,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      },
      // 关注用户的较早帖子
      {
        id: 10,
        content: '最近在学习新的技能，感觉每天都在进步，很有成就感！',
        zodiac: '天秤座', // 关注用户
        createTime: new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000),
        likeCount: 8,
        commentCount: 4,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      }
    ]

    this.setData({
      posts: mockPosts,
      filteredPosts: mockPosts
    })
  },

  // 输入内容
  onPostInput(e) {
    this.setData({
      postContent: e.detail.value
    })
  },

  // 发布帖子
  submitPost() {
    const { postContent, userZodiac, posts } = this.data
    
    if (!postContent.trim()) {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return
    }

    this.setData({ posting: true })

    // 模拟发布延迟
    setTimeout(() => {
      const newPost = {
        id: Date.now(),
        content: postContent.trim(),
        zodiac: userZodiac || '神秘星座',
        createTime: new Date(),
        likeCount: 0,
        commentCount: 0,
        liked: false,
        showComments: false,
        commentInput: '',
        comments: []
      }

      const updatedPosts = [newPost, ...posts]
      
      this.setData({
        posts: updatedPosts,
        filteredPosts: updatedPosts,
        postContent: '',
        posting: false
      })

      wx.showToast({
        title: '发布成功！',
        icon: 'success'
      })
    }, 1500)
  },

  // 切换筛选
  switchFilter(e) {
    const filter = e.currentTarget.dataset.filter
    const { posts, followingUsers, sortType } = this.data
    let filteredPosts = []

    switch (filter) {
      case 'all':
        // 全部：所有帖子
        filteredPosts = [...posts]
        break
        
      case 'follow':
        // 关注：只显示关注用户的帖子
        filteredPosts = posts.filter(post => 
          followingUsers.includes(post.zodiac)
        )
        break
        
      case 'hot':
        // 热门：按互动热度排序，互动数>=3
        filteredPosts = posts
          .map(post => ({
            ...post,
            hotScore: post.likeCount + post.commentCount * 2
          }))
          .filter(post => post.hotScore >= 3)
        break
        
      case 'nearby':
        // 附近：显示同城用户的帖子（模拟数据）
        filteredPosts = posts.filter(post => {
          // 模拟：白羊座、双子座、狮子座为同城用户
          const nearbyCities = ['白羊座', '双子座', '狮子座', '水瓶座']
          return nearbyCities.includes(post.zodiac)
        })
        break
        
      default:
        filteredPosts = [...posts]
    }

    // 应用排序
    this.applySorting(filteredPosts, sortType)

    console.log(`${filter}筛选结果:`, filteredPosts.length, '条帖子')

    this.setData({
      currentFilter: filter,
      filteredPosts
    })
  },

  // 切换排序
  switchSort(e) {
    const sort = e.currentTarget.dataset.sort
    const { filteredPosts } = this.data
    
    this.applySorting(filteredPosts, sort)
    
    this.setData({
      sortType: sort,
      filteredPosts
    })
  },

  // 应用排序逻辑
  applySorting(posts, sortType) {
    if (sortType === 'heat') {
      // 按热度排序
      posts.sort((a, b) => {
        const scoreA = a.likeCount + a.commentCount * 2
        const scoreB = b.likeCount + b.commentCount * 2
        return scoreB - scoreA
      })
    } else {
      // 按时间排序（默认）
      posts.sort((a, b) => new Date(b.createTime) - new Date(a.createTime))
    }
  },

  // 点赞/取消点赞
  toggleLike(e) {
    const postId = parseInt(e.currentTarget.dataset.id)
    const { posts } = this.data
    
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          liked: !post.liked,
          likeCount: post.liked ? post.likeCount - 1 : post.likeCount + 1
        }
      }
      return post
    })

    this.setData({
      posts: updatedPosts,
      filteredPosts: updatedPosts
    })

    // 添加点赞动画效果
    const animation = wx.createAnimation({
      duration: 300,
      timingFunction: 'ease'
    })
    animation.scale(1.2).step()
    animation.scale(1).step()
    
    // 这里可以添加更多动画效果
  },

  // 切换评论显示
  toggleComments(e) {
    const postId = parseInt(e.currentTarget.dataset.id)
    const { posts } = this.data
    
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          showComments: !post.showComments
        }
      }
      return post
    })

    this.setData({
      posts: updatedPosts,
      filteredPosts: updatedPosts
    })
  },

  // 输入评论
  onCommentInput(e) {
    const postId = parseInt(e.currentTarget.dataset.id)
    const { posts } = this.data
    
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          commentInput: e.detail.value
        }
      }
      return post
    })

    this.setData({
      posts: updatedPosts,
      filteredPosts: updatedPosts
    })
  },

  // 提交评论
  submitComment(e) {
    const postId = parseInt(e.currentTarget.dataset.id)
    const { posts, userZodiac } = this.data
    
    const updatedPosts = posts.map(post => {
      if (post.id === postId && post.commentInput.trim()) {
        const newComment = {
          id: Date.now(),
          content: post.commentInput.trim(),
          zodiac: userZodiac || '神秘星座',
          createTime: new Date()
        }
        
        return {
          ...post,
          comments: [...(post.comments || []), newComment],
          commentCount: post.commentCount + 1,
          commentInput: ''
        }
      }
      return post
    })

    this.setData({
      posts: updatedPosts,
      filteredPosts: updatedPosts
    })

    wx.showToast({
      title: '评论成功',
      icon: 'success'
    })
  },

  // 分享帖子
  sharePost(e) {
    const postId = e.currentTarget.dataset.id
    wx.showToast({
      title: '分享功能开发中',
      icon: 'none'
    })
  },

  // 获取星座符号
  getZodiacSymbol(sign) {
    const symbols = {
      '白羊座': '♈', '金牛座': '♉', '双子座': '♊', '巨蟹座': '♋',
      '狮子座': '♌', '处女座': '♍', '天秤座': '♎', '天蝎座': '♏',
      '射手座': '♐', '摩羯座': '♑', '水瓶座': '♒', '双鱼座': '♓'
    }
    return symbols[sign] || '⭐'
  },

  // 格式化时间
  formatTime(date) {
    const now = new Date()
    const postTime = new Date(date)
    const diff = now - postTime
    
    const minutes = Math.floor(diff / (1000 * 60))
    const hours = Math.floor(diff / (1000 * 60 * 60))
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    
    if (minutes < 1) return '刚刚'
    if (minutes < 60) return `${minutes}分钟前`
    if (hours < 24) return `${hours}小时前`
    if (days < 7) return `${days}天前`
    
    return postTime.toLocaleDateString()
  }
})