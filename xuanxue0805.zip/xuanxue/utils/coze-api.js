// utils/coze-api.js
const app = getApp()

/**
 * 调用Coze API进行星座分析
 * @param {Object} userData - 用户数据
 * @returns {Promise} API响应
 */
function callZodiacAnalysis(userData) {
  return new Promise((resolve, reject) => {
    console.log('开始调用Coze星座分析API', userData)
    
    const { cozeApiUrl, cozeApiKey, zodiacWorkflowId, apiTimeout } = app.globalData
    
    wx.request({
      url: cozeApiUrl,
      method: 'POST',
      timeout: apiTimeout,
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${cozeApiKey}`,
        'Accept': 'application/json',

      },
      data: {
        conversation_id: generateConversationId(),
        bot_id: zodiacWorkflowId,
        user: userData.userName || 'anonymous',
        query: `请分析以下用户的星座信息：
出生日期：${userData.birthDate}
出生时间：${userData.birthTime}
出生地点：${userData.birthPlace}
姓名：${userData.userName || '匿名用户'}

请计算并返回该用户的太阳星座、上升星座、月亮星座、星座元素、星座模式和兼容性信息。

返回格式示例：
{
  "sign": "白羊座",
  "rising": "金牛座",
  "moon": "双子座",
  "element": "火",
  "modality": "基本",
  "compatibility": "与火象星座最配"
}`,
        chat_history: [],
        stream: false
      },
      success: (res) => {
        console.log('Coze星座分析API响应:', res)
        
        if (res.statusCode === 200) {
          try {
            // 检查响应数据
            if (res.data && res.data.code) {
              // 处理Coze API错误码
              if (res.data.code === 702242002) {
                reject(new Error('702242002: Coze服务器暂时繁忙，请稍后重试'))
                return
              } else if (res.data.code !== 0) {
                reject(new Error(`Coze API错误: ${res.data.code} - ${res.data.msg || '未知错误'}`))
                return
              }
            }
            
            const zodiacInfo = parseZodiacResponse(res.data)
            resolve(zodiacInfo)
          } catch (parseError) {
            console.error('解析响应失败:', parseError)
            // 即使解析失败也返回基础信息
            resolve({
              sign: '白羊座',
              rising: '未知',
              moon: '未知',
              element: '火',
              modality: '基本',
              compatibility: '与火象星座最配',
              note: 'AI分析完成，部分信息解析异常，请重试'
            })
          }
        } else {
          console.error('API调用失败:', res)
          reject(new Error(`网络请求失败: HTTP ${res.statusCode}`))
        }
      },
      fail: (error) => {
        console.error('星座分析API网络错误:', error)
        
        // 检查是否是服务器错误，如果是则尝试重试
        if (error.errMsg && error.errMsg.includes('timeout')) {
          reject(new Error('请求超时，请检查网络连接'))
        } else {
          reject(new Error('网络请求失败'))
        }
      }
    })
  })
}

/**
 * 解析Coze API星座分析响应
 * @param {Object} responseData - API响应数据
 * @returns {Object} 解析后的星座信息
 */
function parseZodiacResponse(responseData) {
  console.log('开始解析星座响应数据:', responseData)
  
  try {
    // 处理不同的响应格式
    let content = ''
    
    if (responseData.data) {
      content = responseData.data
    } else if (responseData.messages && responseData.messages.length > 0) {
      const lastMessage = responseData.messages[responseData.messages.length - 1]
      if (lastMessage.content) {
        content = lastMessage.content
      } else if (lastMessage.text) {
        content = lastMessage.text
      }
    } else if (responseData.content) {
      content = responseData.content
    } else if (typeof responseData === 'string') {
      content = responseData
    }
    
    console.log('提取的内容:', content)
    
    // 尝试Base64解码
    if (content && typeof content === 'string' && content.length > 50 && !content.includes('{')) {
      try {
        const decoded = wx.base64ToArrayBuffer ? wx.base64ToArrayBuffer(content) : content
        if (decoded && decoded !== content) {
          content = String.fromCharCode.apply(null, new Uint8Array(decoded))
          console.log('Base64解码后:', content)
        }
      } catch (decodeError) {
        console.log('Base64解码失败，使用原始内容:', decodeError)
      }
    }
    
    // 尝试直接JSON解析
    if (content) {
      try {
        const parsed = JSON.parse(content)
        if (parsed.sign || parsed.星座) {
          console.log('直接JSON解析成功:', parsed)
          return normalizeZodiacData(parsed)
        }
      } catch (jsonError) {
        console.log('直接JSON解析失败，尝试提取JSON片段')
      }
      
      // 尝试从字符串中提取JSON
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0])
          console.log('提取JSON片段成功:', parsed)
          return normalizeZodiacData(parsed)
        } catch (extractError) {
          console.log('提取JSON片段失败')
        }
      }
      
      // 文本解析
      return parseTextToZodiac(content)
    }
    
    throw new Error('无法找到有效的响应内容')
    
  } catch (error) {
    console.error('解析星座响应失败:', error)
    // 返回默认数据而不是抛出错误
    return {
      sign: '白羊座',
      rising: '未知',
      moon: '未知',
      element: '火',
      modality: '基本',
      compatibility: '与火象星座最配',
      note: 'AI分析完成，部分信息可能不完整'
    }
  }
}

/**
 * 从文本中解析星座信息
 * @param {string} text - 文本内容
 * @returns {Object} 星座信息
 */
function parseTextToZodiac(text) {
  console.log('使用文本解析星座信息:', text)
  
  const zodiacInfo = {
    sign: '白羊座',
    rising: '',
    moon: '',
    element: '',
    modality: '',
    compatibility: '',
    note: 'AI分析完成'
  }
  
  // 星座正则匹配
  const zodiacRegex = /(白羊座|金牛座|双子座|巨蟹座|狮子座|处女座|天秤座|天蝎座|射手座|摩羯座|水瓶座|双鱼座)/g
  const zodiacs = text.match(zodiacRegex) || []
  
  // 匹配太阳星座
  const sunMatch = text.match(/(?:太阳星座|主星座|星座)[\s：:]*([^\s\n，,。.]+)/)
  if (sunMatch) {
    zodiacInfo.sign = sunMatch[1]
  } else if (zodiacs.length > 0) {
    zodiacInfo.sign = zodiacs[0]
  }
  
  // 匹配上升星座
  const risingMatch = text.match(/(?:上升星座)[\s：:]*([^\s\n，,。.]+)/)
  if (risingMatch) {
    zodiacInfo.rising = risingMatch[1]
  } else if (zodiacs.length > 1) {
    zodiacInfo.rising = zodiacs[1]
  }
  
  // 匹配月亮星座
  const moonMatch = text.match(/(?:月亮星座)[\s：:]*([^\s\n，,。.]+)/)
  if (moonMatch) {
    zodiacInfo.moon = moonMatch[1]
  } else if (zodiacs.length > 2) {
    zodiacInfo.moon = zodiacs[2]
  }
  
  // 匹配元素
  const elementMatch = text.match(/(?:星座元素|元素)[\s：:]*([火土风水])/)
  if (elementMatch) {
    zodiacInfo.element = elementMatch[1]
  }
  
  // 匹配模式
  const modalityMatch = text.match(/(?:星座模式|模式)[\s：:]*([基本固定变动])/)
  if (modalityMatch) {
    zodiacInfo.modality = modalityMatch[1]
  }
  
  // 匹配兼容性
  const compatibilityMatch = text.match(/(?:兼容性|配对|最配)[\s：:]*([^\n。.]+)/)
  if (compatibilityMatch) {
    zodiacInfo.compatibility = compatibilityMatch[1]
  }
  
  console.log('文本解析结果:', zodiacInfo)
  return zodiacInfo
}

/**
 * 标准化星座数据
 * @param {Object} data - 原始数据
 * @returns {Object} 标准化后的数据
 */
function normalizeZodiacData(data) {
  return {
    sign: data.sign || data.星座 || data.太阳星座 || '白羊座',
    rising: data.rising || data.上升星座 || '',
    moon: data.moon || data.月亮星座 || '',
    element: data.element || data.星座元素 || '',
    modality: data.modality || data.星座模式 || '',
    compatibility: data.compatibility || data.兼容性 || '',
    note: data.note || data.备注 || 'AI分析完成'
  }
}

/**
 * 调用Coze API进行运势预测
 * @param {string} targetDate - 目标日期
 * @param {Object} userInfo - 用户信息
 * @returns {Promise} API响应
 */
function callFortunePredict(targetDate, userInfo) {
  return new Promise((resolve, reject) => {
    console.log('开始调用Coze运势预测API', targetDate, userInfo)
    
    const { cozeApiUrl, cozeApiKey, fortuneWorkflowId, apiTimeout } = app.globalData
    
    wx.request({
      url: cozeApiUrl,
      method: 'POST',
      timeout: apiTimeout,
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${cozeApiKey}`,
        'Accept': 'application/json',

      },
      data: {
        conversation_id: generateConversationId(),
        bot_id: fortuneWorkflowId,
        user: userInfo?.userName || 'anonymous',
        query: `请预测以下用户在指定日期的运势：
目标日期：${targetDate}
用户星座：${userInfo?.zodiacInfo?.sign || '未知'}
出生信息：${userInfo?.birthDate || ''} ${userInfo?.birthTime || ''} ${userInfo?.birthPlace || ''}

请返回该日期的运势预测、推荐穿衣颜色和配饰选择。

返回格式示例：
{
  "targetDate": "${targetDate}",
  "fortune": "今日运势描述",
  "color": "推荐颜色",
  "accessory": "推荐配饰"
}`,
        chat_history: [],
        stream: false
      },
      success: (res) => {
        console.log('Coze运势预测API响应:', res)
        
        if (res.statusCode === 200) {
          try {
            // 检查响应数据
            if (res.data && res.data.code) {
              // 处理Coze API错误码
              if (res.data.code === 702242002) {
                reject(new Error('702242002: Coze服务器暂时繁忙，请稍后重试'))
                return
              } else if (res.data.code !== 0) {
                reject(new Error(`Coze API错误: ${res.data.code} - ${res.data.msg || '未知错误'}`))
                return
              }
            }
            
            const fortuneData = parseFortuneResponse(res.data, targetDate)
            resolve(fortuneData)
          } catch (parseError) {
            console.error('解析运势响应失败:', parseError)
            // 即使解析失败也返回基础信息
            resolve({
              targetDate: targetDate,
              fortune: '今日运势平稳，适合保持积极心态',
              color: '蓝色',
              accessory: '银饰',
              note: 'AI预测完成，部分信息解析异常，请重试'
            })
          }
        } else {
          console.error('运势API调用失败:', res)
          reject(new Error(`网络请求失败: HTTP ${res.statusCode}`))
        }
      },
      fail: (error) => {
        console.error('运势预测API网络错误:', error)
        
        if (error.errMsg && error.errMsg.includes('timeout')) {
          reject(new Error('请求超时，请检查网络连接'))
        } else {
          reject(new Error('网络请求失败'))
        }
      }
    })
  })
}

/**
 * 解析运势预测响应
 * @param {Object} responseData - API响应数据
 * @param {string} targetDate - 目标日期
 * @returns {Object} 解析后的运势数据
 */
function parseFortuneResponse(responseData, targetDate) {
  console.log('开始解析运势响应数据:', responseData)
  
  try {
    // 处理不同的响应格式
    let content = ''
    
    if (responseData.data) {
      content = responseData.data
    } else if (responseData.messages && responseData.messages.length > 0) {
      const lastMessage = responseData.messages[responseData.messages.length - 1]
      if (lastMessage.content) {
        content = lastMessage.content
      } else if (lastMessage.text) {
        content = lastMessage.text
      }
    } else if (responseData.content) {
      content = responseData.content
    } else if (typeof responseData === 'string') {
      content = responseData
    }
    
    console.log('提取的运势内容:', content)
    
    // 尝试Base64解码
    if (content && typeof content === 'string' && content.length > 50 && !content.includes('{')) {
      try {
        const decoded = wx.base64ToArrayBuffer ? wx.base64ToArrayBuffer(content) : content
        if (decoded && decoded !== content) {
          content = String.fromCharCode.apply(null, new Uint8Array(decoded))
          console.log('运势Base64解码后:', content)
        }
      } catch (decodeError) {
        console.log('运势Base64解码失败，使用原始内容:', decodeError)
      }
    }
    
    // 尝试直接JSON解析
    if (content) {
      try {
        const parsed = JSON.parse(content)
        if (parsed.fortune || parsed.目标日运势) {
          console.log('运势直接JSON解析成功:', parsed)
          return normalizeFortuneData(parsed, targetDate)
        }
      } catch (jsonError) {
        console.log('运势直接JSON解析失败，尝试提取JSON片段')
      }
      
      // 尝试从字符串中提取JSON
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0])
          console.log('运势提取JSON片段成功:', parsed)
          return normalizeFortuneData(parsed, targetDate)
        } catch (extractError) {
          console.log('运势提取JSON片段失败')
        }
      }
      
      // 文本解析
      return parseTextToFortune(content, targetDate)
    }
    
    throw new Error('无法找到有效的运势响应内容')
    
  } catch (error) {
    console.error('解析运势响应失败:', error)
    // 返回默认数据而不是抛出错误
    return {
      targetDate: targetDate,
      fortune: '今日运势平稳，适合保持积极心态',
      color: '蓝色',
      accessory: '银饰',
      note: 'AI预测完成，部分信息可能不完整'
    }
  }
}

/**
 * 从文本中解析运势信息
 * @param {string} text - 文本内容
 * @param {string} targetDate - 目标日期
 * @returns {Object} 运势信息
 */
function parseTextToFortune(text, targetDate) {
  console.log('使用文本解析运势信息:', text)
  
  const fortuneData = {
    targetDate: targetDate,
    fortune: '',
    color: '',
    accessory: '',
    note: 'AI预测完成'
  }
  
  // 匹配运势描述
  const fortuneMatch = text.match(/(?:今日运势|运势|预测)[\s：:]*([^\n。.]+)/)
  if (fortuneMatch) {
    fortuneData.fortune = fortuneMatch[1]
  } else {
    // 如果没有明确的运势标识，取第一句话
    const sentences = text.split(/[。.！!？?]/)
    if (sentences.length > 0 && sentences[0].trim()) {
      fortuneData.fortune = sentences[0].trim()
    }
  }
  
  // 匹配颜色
  const colorMatch = text.match(/(?:颜色|色彩|穿衣|幸运色)[\s：:]*([^\s\n，,。.]+)/)
  if (colorMatch) {
    fortuneData.color = colorMatch[1]
  }
  
  // 匹配配饰
  const accessoryMatch = text.match(/(?:配饰|饰品|佩戴)[\s：:]*([^\n。.]+)/)
  if (accessoryMatch) {
    fortuneData.accessory = accessoryMatch[1]
  }
  
  console.log('运势文本解析结果:', fortuneData)
  return fortuneData
}

/**
 * 标准化运势数据
 * @param {Object} data - 原始数据
 * @param {string} targetDate - 目标日期
 * @returns {Object} 标准化后的数据
 */
function normalizeFortuneData(data, targetDate) {
  return {
    targetDate: data.targetDate || data.目标日时间 || targetDate,
    fortune: data.fortune || data.目标日运势 || '',
    color: data.color || data.目标日穿衣颜色推荐 || '',
    accessory: data.accessory || data.目标日配饰选择 || '',
    note: data.note || data.备注 || 'AI预测完成'
  }
}

/**
 * 生成会话ID
 * @returns {string} 会话ID
 */
function generateConversationId() {
  return 'conv_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
}

/**
 * 智能API重试机制
 * @param {Function} apiCall - API调用函数
 * @param {number} maxRetries - 最大重试次数
 * @returns {Promise} API响应
 */
function retryApiCall(apiCall, maxRetries = 3) {
  return new Promise((resolve, reject) => {
    let attempts = 0
    
    function attempt() {
      attempts++
      console.log(`API调用尝试 ${attempts}/${maxRetries + 1}`)
      
      apiCall()
        .then(resolve)
        .catch((error) => {
          console.log(`第${attempts}次调用失败:`, error.message)
          
          // 检查是否是可重试的错误
          const isRetryableError = 
            error.message.includes('702242002') || 
            error.message.includes('server issues') ||
            error.message.includes('timeout') ||
            error.message.includes('网络请求失败')
          
          if (attempts > maxRetries || !isRetryableError) {
            reject(error)
          } else {
            const delay = Math.min(1000 * Math.pow(2, attempts - 1), 5000) // 指数退避，最大5秒
            console.log(`${delay}ms后重试...`)
            setTimeout(attempt, delay)
          }
        })
    }
    
    attempt()
  })
}

/**
 * 增强的星座分析API调用（带重试）
 * @param {Object} userData - 用户数据
 * @returns {Promise} API响应
 */
function callZodiacAnalysisWithRetry(userData) {
  return retryApiCall(() => callZodiacAnalysis(userData), 2)
}

/**
 * 增强的运势预测API调用（带重试）
 * @param {string} targetDate - 目标日期
 * @param {Object} userInfo - 用户信息
 * @returns {Promise} API响应
 */
function callFortuneWithRetry(targetDate, userInfo) {
  return retryApiCall(() => callFortunePredict(targetDate, userInfo), 2)
}

module.exports = {
  callZodiacAnalysis,
  callFortunePredict,
  callZodiacAnalysisWithRetry,
  callFortuneWithRetry,
  retryApiCall
}