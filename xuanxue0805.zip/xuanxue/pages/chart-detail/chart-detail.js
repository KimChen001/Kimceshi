// 星盘详细解读页面
import * as echarts from '../components/ec-canvas/echarts'
const app = getApp()

Page({
  data: {
    userInfo: {},
    zodiacInfo: {},
    birthChartConfig: {
      onInit: null
    }
  },

  onLoad(options) {
    console.log('星盘详解页面加载')
    
    // 获取用户信息
    const globalUserInfo = app.globalData.userInfo
    if (globalUserInfo) {
      this.setData({
        userInfo: globalUserInfo,
        zodiacInfo: globalUserInfo.zodiacInfo || {}
      })
      
      // 初始化星盘图
      this.initBirthChart()
    }
  },

  // 初始化专业星盘图
  initBirthChart() {
    this.setData({
      birthChartConfig: {
        onInit: this.initBirthChartCanvas.bind(this)
      }
    })
  },

  // 初始化星盘Canvas
  initBirthChartCanvas(canvas, width, height, dpr) {
    const chart = echarts.init(canvas, null, {
      width: width,
      height: height,
      devicePixelRatio: dpr
    })
    canvas.setChart(chart)

    const option = this.getBirthChartOption()
    chart.setOption(option)
    return chart
  },

  // 获取星盘图配置
  getBirthChartOption() {
    const { zodiacInfo } = this.data
    
    // 十二星座的角度位置（从白羊座0度开始，逆时针）
    const zodiacPositions = {
      '白羊座': 0, '金牛座': 30, '双子座': 60, '巨蟹座': 90,
      '狮子座': 120, '处女座': 150, '天秤座': 180, '天蝎座': 210,
      '射手座': 240, '摩羯座': 270, '水瓶座': 300, '双鱼座': 330
    }

    // 获取三大星座的位置
    const sunAngle = zodiacPositions[zodiacInfo.sign] || 0
    const moonAngle = zodiacPositions[zodiacInfo.moon] || 120
    const risingAngle = zodiacPositions[zodiacInfo.rising] || 240

    return {
      backgroundColor: 'rgba(26, 26, 46, 0.9)',
      title: {
        text: '个人星盘',
        left: 'center',
        top: 15,
        textStyle: {
          color: 'rgba(255, 255, 255, 0.9)',
          fontSize: 16,
          fontWeight: '500'
        }
      },
      polar: {
        radius: ['25%', '75%'],
        center: ['50%', '55%']
      },
      radiusAxis: {
        type: 'category',
        data: ['内圈', '中圈', '外圈'],
        show: false
      },
      angleAxis: {
        type: 'value',
        min: 0,
        max: 360,
        interval: 30,
        splitLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.1)',
            width: 1
          }
        },
        axisLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.2)',
            width: 2
          }
        },
        axisLabel: {
          show: false
        }
      },
      series: [
        // 外圈星座标记
        {
          type: 'scatter',
          coordinateSystem: 'polar',
          symbol: 'circle',
          symbolSize: 8,
          data: Object.entries(zodiacPositions).map(([sign, angle]) => [2, angle]),
          itemStyle: {
            color: 'rgba(173, 216, 230, 0.6)'
          },
          label: {
            show: true,
            position: 'outside',
            formatter: (params) => {
              const signs = Object.keys(zodiacPositions)
              const symbols = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓']
              return symbols[signs.indexOf(Object.keys(zodiacPositions)[params.dataIndex])] || ''
            },
            textStyle: {
              color: 'rgba(255, 255, 255, 0.8)',
              fontSize: 14,
              fontWeight: 'bold'
            }
          }
        },
        // 太阳位置
        {
          type: 'scatter',
          coordinateSystem: 'polar',
          symbol: 'circle',
          symbolSize: 20,
          data: [[1.5, sunAngle]],
          itemStyle: {
            color: '#FFD700',
            borderColor: '#FFA500',
            borderWidth: 2
          },
          label: {
            show: true,
            formatter: '☉',
            textStyle: {
              color: '#FFD700',
              fontSize: 16,
              fontWeight: 'bold'
            }
          }
        },
        // 月亮位置
        {
          type: 'scatter',
          coordinateSystem: 'polar',
          symbol: 'circle',
          symbolSize: 16,
          data: [[1.2, moonAngle]],
          itemStyle: {
            color: '#C0C0C0',
            borderColor: '#A9A9A9',
            borderWidth: 2
          },
          label: {
            show: true,
            formatter: '☽',
            textStyle: {
              color: '#C0C0C0',
              fontSize: 14,
              fontWeight: 'bold'
            }
          }
        },
        // 上升位置
        {
          type: 'scatter',
          coordinateSystem: 'polar',
          symbol: 'triangle',
          symbolSize: 14,
          data: [[0.8, risingAngle]],
          itemStyle: {
            color: '#ADD8E6',
            borderColor: '#87CEEB',
            borderWidth: 2
          },
          label: {
            show: true,
            formatter: '↗',
            textStyle: {
              color: '#ADD8E6',
              fontSize: 12,
              fontWeight: 'bold'
            }
          }
        },
        // 宫位分割线
        {
          type: 'line',
          coordinateSystem: 'polar',
          data: Array.from({length: 12}, (_, i) => [
            [0.5, i * 30],
            [2, i * 30]
          ]),
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.1)',
            width: 1
          },
          symbol: 'none'
        }
      ]
    }
  },

  // 获取星座符号
  getZodiacSymbol(sign) {
    const symbols = {
      '白羊座': '♈', '金牛座': '♉', '双子座': '♊', '巨蟹座': '♋',
      '狮子座': '♌', '处女座': '♍', '天秤座': '♎', '天蝎座': '♏',
      '射手座': '♐', '摩羯座': '♑', '水瓶座': '♒', '双鱼座': '♓'
    }
    return symbols[sign] || '⭐'
  },

  // 获取星座描述
  getZodiacDescription(sign) {
    const descriptions = {
      '白羊座': '充满活力和冒险精神，勇敢直接，喜欢挑战和竞争。天生的领导者，行动力强，但有时过于冲动。',
      '金牛座': '稳重务实，追求安全感和舒适生活。有很强的审美能力，喜欢美好的事物，但有时过于固执。',
      '双子座': '聪明机智，好奇心强，善于沟通和学习。思维敏捷，适应性强，但有时缺乏持久力。',
      '巨蟹座': '情感丰富，直觉敏锐，重视家庭和安全感。善于照顾他人，但有时过于敏感和情绪化。',
      '狮子座': '自信大方，有强烈的表现欲和领导欲。慷慨热情，喜欢成为焦点，但有时过于自我中心。',
      '处女座': '细致认真，追求完美和效率。分析能力强，善于服务他人，但有时过于挑剔和焦虑。',
      '天秤座': '优雅和谐，追求平衡和美感。善于协调关系，有很好的审美品味，但有时过于犹豫不决。',
      '天蝎座': '深沉神秘，情感强烈，有很强的洞察力。意志坚定，专注力强，但有时过于极端和占有欲强。',
      '射手座': '自由奔放，乐观向上，热爱冒险和探索。视野开阔，哲学思维强，但有时过于冲动和不负责任。',
      '摩羯座': '务实稳重，目标明确，有很强的责任心。坚持不懈，善于规划，但有时过于严肃和保守。',
      '水瓶座': '独立创新，思想前卫，追求自由和平等。有人道主义精神，但有时过于疏离和固执己见。',
      '双鱼座': '浪漫梦幻，直觉敏锐，富有同情心和想象力。善解人意，艺术天赋强，但有时过于逃避现实。'
    }
    return descriptions[sign] || '独特而神秘的星座特质'
  },

  // 获取元素图标
  getElementIcon(element) {
    const icons = {
      '火': '🔥',
      '土': '🌍', 
      '风': '💨',
      '水': '💧'
    }
    return icons[element] || '⭐'
  },

  // 获取模式图标
  getModalityIcon(modality) {
    const icons = {
      '基本': '🚀',
      '固定': '🏔️',
      '变动': '🌊'
    }
    return icons[modality] || '⭐'
  },

  // 获取元素描述
  getElementDescription(element) {
    const descriptions = {
      '火': '火象星座充满热情和活力，行动力强，喜欢冒险和挑战，具有开拓精神。',
      '土': '土象星座务实稳重，注重现实和物质，有很强的责任感和执行力。',
      '风': '风象星座思维活跃，善于交流和思考，追求自由和新鲜事物。',
      '水': '水象星座情感丰富，直觉敏锐，富有同情心和想象力，重视精神层面。'
    }
    return descriptions[element] || '独特的能量特质'
  },

  // 获取模式描述  
  getModalityDescription(modality) {
    const descriptions = {
      '基本': '基本宫星座善于开创和领导，有很强的主动性和开拓精神，喜欢启动新项目。',
      '固定': '固定宫星座坚持不懈，有很强的意志力和持久力，善于维持和巩固。',
      '变动': '变动宫星座适应性强，灵活多变，善于调节和沟通，能够适应变化。'
    }
    return descriptions[modality] || '独特的行为模式'
  },

  // 返回上一页
  goBack() {
    wx.navigateBack()
  },

  // 分享星盘
  shareChart() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
    
    wx.showToast({
      title: '长按右上角分享',
      icon: 'none'
    })
  },

  // 分享功能
  onShareAppMessage() {
    const zodiacInfo = this.data.zodiacInfo
    return {
      title: `我的星盘：${zodiacInfo.sign} | MOONA星座`,
      path: '/pages/index/index',
      imageUrl: '' // 可以添加星盘截图
    }
  }
})