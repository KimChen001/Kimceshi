// pages/fortune/fortune.js
const app = getApp()
const cozeApi = require('../../utils/coze-api')

Page({
  data: {
    targetDate: '',
    loading: false,
    fortuneData: null,
    useAIMode: false // 默认使用基础预测，避免API问题
  },

  onLoad(options) {
    console.log('运势页面加载', options)
    
    // 获取预加载数据
    const preloadData = app.globalData.preloadData
    
    let targetDate = ''
    let shouldAutoLoad = false
    
    if (preloadData && preloadData.fromPage === 'index') {
      // 使用预加载的数据
      targetDate = preloadData.targetDate
      shouldAutoLoad = true
      console.log('使用预加载数据:', preloadData)
      
      // 清除预加载数据，避免重复使用
      app.globalData.preloadData = null
    } else {
      // 默认使用今天的日期
      const today = new Date()
      targetDate = today.getFullYear() + '-' + 
        String(today.getMonth() + 1).padStart(2, '0') + '-' + 
        String(today.getDate()).padStart(2, '0')
    }
    
    this.setData({
      targetDate: targetDate
    })
    
    // 如果有预加载数据，自动获取运势
    if (shouldAutoLoad) {
      // 短暂延迟后自动加载，给页面渲染时间
      setTimeout(() => {
        this.getFortune()
      }, 100)
    }
  },

  onDateChange(e) {
    this.setData({
      targetDate: e.detail.value
    })
  },

  toggleAIMode(e) {
    this.setData({
      useAIMode: e.detail.value
    })
  },

  selectToday() {
    const today = new Date()
    const dateString = today.getFullYear() + '-' + 
      String(today.getMonth() + 1).padStart(2, '0') + '-' + 
      String(today.getDate()).padStart(2, '0')
    
    this.setData({
      targetDate: dateString
    })
  },

  selectTomorrow() {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    const dateString = tomorrow.getFullYear() + '-' + 
      String(tomorrow.getMonth() + 1).padStart(2, '0') + '-' + 
      String(tomorrow.getDate()).padStart(2, '0')
    
    this.setData({
      targetDate: dateString
    })
  },

  selectWeekend() {
    const today = new Date()
    const daysUntilSaturday = (6 - today.getDay()) % 7
    const saturday = new Date(today)
    saturday.setDate(today.getDate() + daysUntilSaturday)
    
    const dateString = saturday.getFullYear() + '-' + 
      String(saturday.getMonth() + 1).padStart(2, '0') + '-' + 
      String(saturday.getDate()).padStart(2, '0')
    
    this.setData({
      targetDate: dateString
    })
  },

  getFortune() {
    const { targetDate, useAIMode } = this.data
    const userInfo = app.globalData.userInfo

    if (!targetDate) {
      wx.showToast({
        title: '请选择日期',
        icon: 'none'
      })
      return
    }

    // 检查缓存 - 提升性能
    const cacheKey = `fortune_${targetDate}_${useAIMode ? 'ai' : 'basic'}`
    const cachedData = wx.getStorageSync(cacheKey)
    
    if (cachedData) {
      console.log('使用缓存的运势数据')
      this.setData({
        fortuneData: cachedData,
        loading: false
      })
      
      wx.showToast({
        title: '运势加载完成',
        icon: 'success',
        duration: 1000
      })
      return
    }

    this.setData({ loading: true })

    if (useAIMode) {
      this.callFortuneAPI(targetDate, userInfo)
    } else {
      this.useMockFortuneData(targetDate)
    }
  },

  callFortuneAPI(targetDate, userInfo) {
    console.log('调用Coze API进行运势预测', targetDate, userInfo)
    
    cozeApi.callFortuneWithRetry(targetDate, userInfo)
      .then((fortuneData) => {
        console.log('Coze API运势预测结果:', fortuneData)
        
        this.setData({
          fortuneData,
          loading: false
        })
        
        wx.showToast({
          title: 'AI预测完成',
          icon: 'success'
        })
      })
      .catch((error) => {
        console.error('运势预测API调用失败:', error)
        
        let errorMessage = '预测失败，请重试'
        let showModal = false
        
        if (error.message.includes('702242002')) {
          errorMessage = 'Coze服务器暂时繁忙'
          showModal = true
        } else if (error.message.includes('timeout')) {
          errorMessage = '网络超时，请检查网络连接'
        } else if (error.message.includes('网络请求失败')) {
          errorMessage = '网络连接失败'
        }
        
        this.setData({ loading: false })
        
        if (showModal) {
          wx.showModal({
            title: '温馨提示',
            content: 'Coze服务器暂时遇到问题，建议：\n\n1. 稍后重试\n2. 或开启测试模式体验完整功能\n\n我们正在努力修复！',
            confirmText: '使用模拟数据',
            cancelText: '稍后重试',
            success: (res) => {
              if (res.confirm) {
                this.setData({ useAIMode: false })
                this.getFortune() // 重新获取，使用模拟数据
              }
            }
          })
        } else {
          wx.showToast({
            title: errorMessage,
            icon: 'none'
          })
        }
      })
  },

  useMockFortuneData(targetDate) {
    console.log('使用模拟数据进行运势预测')
    
    const mockFortunes = [
      '今日运势极佳，适合开展新项目，爱情运势旺盛',
      '今日财运亨通，投资理财有望获得收益，工作顺利',
      '今日健康运势良好，适合户外活动，人际关系和谐',
      '今日创意灵感丰富，适合艺术创作，学习效率高',
      '今日事业运势上升，领导力得到认可，合作机会增多'
    ]
    
    const mockColors = ['红色', '蓝色', '绿色', '紫色', '金色', '银色', '粉色', '橙色']
    const mockAccessories = ['水晶项链', '银手镯', '珍珠耳环', '玉石戒指', '金属手表', '丝绸围巾', '羊毛帽子']
    const mockLoveMessages = ['单身者有机会遇到心仪对象', '恋人关系和谐甜蜜', '夫妻感情稳定温馨', '桃花运旺盛，把握机会']
    const mockCareerMessages = ['工作进展顺利，获得认可', '有新的合作机会出现', '适合展示才华的好时机', '团队合作默契，效率提升']
    const mockMoneyMessages = ['财运稳定，收入有保障', '投资需谨慎，避免冲动', '有意外收入的可能', '理财规划需要调整']
    const mockHealthMessages = ['身体状况良好，精力充沛', '注意休息，避免过度劳累', '适合运动锻炼的好日子', '饮食清淡，保持健康']
    
    // 模拟API延迟
    setTimeout(() => {
      const fortuneData = {
        targetDate: targetDate,
        fortune: mockFortunes[Math.floor(Math.random() * mockFortunes.length)],
        color: mockColors[Math.floor(Math.random() * mockColors.length)],
        accessory: mockAccessories[Math.floor(Math.random() * mockAccessories.length)],
        love: mockLoveMessages[Math.floor(Math.random() * mockLoveMessages.length)],
        career: mockCareerMessages[Math.floor(Math.random() * mockCareerMessages.length)],
        money: mockMoneyMessages[Math.floor(Math.random() * mockMoneyMessages.length)],
        health: mockHealthMessages[Math.floor(Math.random() * mockHealthMessages.length)],
        score: Math.floor(Math.random() * 2) + 3, // 3-5星
        luckyNumber: Math.floor(Math.random() * 99) + 1,
        luckyTime: ['08:00-10:00', '14:00-16:00', '19:00-21:00'][Math.floor(Math.random() * 3)],
        note: '这是本地模拟数据，如需AI预测请开启AI智能预测。'
      }
      
      this.setData({
        fortuneData,
        loading: false
      })
      
      // 缓存数据 - 提升后续访问速度
      const cacheKey = `fortune_${targetDate}_basic`
      wx.setStorageSync(cacheKey, fortuneData)
      
      wx.showToast({
        title: '模拟预测完成',
        icon: 'success'
      })
    }, 1500)
  },

  // 分享运势
  shareFortune() {
    wx.showToast({
      title: '分享功能开发中',
      icon: 'none'
    })
  },

  // 收藏运势
  collectFortune() {
    const { fortuneData } = this.data
    if (!fortuneData) return

    // 获取现有收藏
    let collections = wx.getStorageSync('fortuneCollections') || []
    
    // 检查是否已收藏
    const exists = collections.some(item => 
      item.targetDate === fortuneData.targetDate && 
      item.fortune === fortuneData.fortune
    )
    
    if (exists) {
      wx.showToast({
        title: '已经收藏过了',
        icon: 'none'
      })
      return
    }
    
    // 添加到收藏
    const collectItem = {
      id: Date.now(),
      ...fortuneData,
      collectTime: new Date()
    }
    
    collections.unshift(collectItem)
    
    // 最多保存50条收藏
    if (collections.length > 50) {
      collections = collections.slice(0, 50)
    }
    
    wx.setStorageSync('fortuneCollections', collections)
    
    wx.showToast({
      title: '收藏成功',
      icon: 'success'
    })
  },

  // 快速预测今日运势
  quickFortune() {
    // 设置为今天
    const today = new Date()
    const todayStr = today.getFullYear() + '-' + 
      String(today.getMonth() + 1).padStart(2, '0') + '-' + 
      String(today.getDate()).padStart(2, '0')
    
    this.setData({
      targetDate: todayStr
    })
    
    // 立即获取运势
    setTimeout(() => {
      this.getFortune()
    }, 100)
    
    wx.showToast({
      title: '正在为您预测今日运势',
      icon: 'loading',
      duration: 1000
    })
  },

  goBack() {
    wx.navigateBack()
  }
})